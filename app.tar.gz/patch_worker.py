import os
import sys
import time
import json
import shutil
import argparse

parser = argparse.ArgumentParser()
parser.add_argument("--env", choices=["prod", "homolog"], default="homolog",
                    help="Ambiente de destino: 'homolog' ou 'prod'")
args, _ = parser.parse_known_args()

is_homolog = (args.env == "homolog")
app_name = "SmartFrota (Homolog)" if is_homolog else "SmartFrota"
app_short = "SmartFrota HML" if is_homolog else "SmartFrota"
app_desc = "SmartFrota - Ambiente de Homologação" if is_homolog else "SmartFrota - Gestão Inteligente de Frota"
theme_color = "#EA580C" if is_homolog else "#2563EB"

# 1. Patch python-worker.js
worker_path = os.path.join("dist", "python-worker.js")
if os.path.exists(worker_path):
    with open(worker_path, "r", encoding="utf-8") as f:
        content = f.read()
    
    patched = False

    load_target = 'await self.pyodide.loadPackage("micropip");'
    load_replacement = 'await self.pyodide.loadPackage(["micropip", "msgpack", "sqlite3"]);'
    if 'await self.pyodide.loadPackage(["micropip", "msgpack"]);' in content:
        content = content.replace('await self.pyodide.loadPackage(["micropip", "msgpack"]);', load_replacement)
        patched = True
    elif load_target in content:
        content = content.replace(load_target, load_replacement)
        patched = True

    app_target_1 = 'response = await pyfetch("app.tar.gz", cache="no-store")'
    app_target_2 = 'response = await pyfetch("app.tar.gz")'
    app_replacement = 'try:\n        response = await pyfetch("app.tar.gz", cache="reload")\n    except Exception:\n        response = await pyfetch("app.tar.gz")'
    if app_target_1 in content:
        content = content.replace(app_target_1, app_replacement)
        patched = True
    elif app_target_2 in content:
        content = content.replace(app_target_2, app_replacement)
        patched = True

    # Sanitização robusta de dependências no Pyodide
    # Garante que flet -> flet-pyodide==0.23.2 e remove pacotes conflitantes
    pyodide_deps_logic = '''if os.path.exists("requirements.txt"):
        with open("requirements.txt", "r") as f:
            raw_lines = [line.rstrip() for line in f]
    else:
        raw_lines = ["flet-pyodide==0.23.2"]
    deps = []
    for line in raw_lines:
        d = line.strip()
        if not d or d.startswith("#"):
            continue
        if d.startswith("flet==") or d.startswith("flet>=") or d == "flet" or "flet-pyodide" in d:
            deps.append("flet-pyodide==0.23.2")
        elif "geolocator" in d or "sqlite" in d:
            continue
        else:
            deps.append(d)
    if not any("flet-pyodide" in x for x in deps):
        deps.insert(0, "flet-pyodide==0.23.2")
    seen = set()
    clean_deps = []
    for d in deps:
        if d not in seen:
            seen.add(d)
            clean_deps.append(d)
    print("SmartFrota: instalando pacotes Pyodide:", clean_deps)
    for pkg in clean_deps:
        try:
            await micropip.install(pkg, pre=${pre})
            print(f"SmartFrota: instalado com sucesso: {pkg}")
        except Exception as _pip_err:
            print(f"SmartFrota: aviso ao instalar {pkg}: {_pip_err}")'''

    # Localiza o bloco de requirements no python-worker.js gerado pelo Flet
    import re
    req_pattern = r'if os\.path\.exists\("requirements\.txt"\):.*?await micropip\.install\([^)]+\)'
    if re.search(req_pattern, content, re.DOTALL):
        content = re.sub(req_pattern, pyodide_deps_logic, content, flags=re.DOTALL)
        patched = True

    # Persistência IDBFS: monta o filesystem no IndexedDB para o banco local
    # (local_cache.db) sobreviver ao fechamento/recarga do app no navegador.
    idbfs_target = "    pyodide.pyimport(self.pythonModuleName);"
    idbfs_replacement = """    // Persistencia (IDBFS): monta o filesystem no IndexedDB e carrega dados salvos
    try {
        try { self.pyodide.FS.mkdir('/home/pyodide/persist'); } catch (e) {}
        self.pyodide.FS.mount(self.pyodide.FS.filesystems.IDBFS, {}, '/home/pyodide/persist');
        await new Promise((resolve, reject) => {
            self.pyodide.FS.syncfs(true, (err) => err ? reject(err) : resolve());
        });
    } catch (e) {
        console.warn('Persistencia IDBFS indisponivel:', e);
    }
    pyodide.pyimport(self.pythonModuleName);"""
    if idbfs_target in content:
        content = content.replace(idbfs_target, idbfs_replacement)
        patched = True

    if patched:
        with open(worker_path, "w", encoding="utf-8") as f:
            f.write(content)
        print("Patch de versao do flet-pyodide e pre-load do msgpack aplicados no worker!")
    else:
        print("Aviso: Alvos do patch ja aplicados ou nao encontrados no python-worker.js")
else:
    print("Erro: python-worker.js nao encontrado!")

# 2. Patch index.html para quebrar cache do Service Worker e injetar bridge de GPS
index_path = os.path.join("dist", "index.html")
if os.path.exists(index_path):
    with open(index_path, "r", encoding="utf-8") as f:
        content = f.read()

    import re

    # a) Cache bust do Service Worker
    new_version = f'const serviceWorkerVersion = "{int(time.time())}";'
    content, count = re.subn(r'const serviceWorkerVersion = "\d+";', new_version, content)
    if count > 0:
        print(f"Cache bust aplicado no index.html (Versao: {int(time.time())})!")
    else:
        print("Aviso: Nao foi possivel atualizar serviceWorkerVersion no index.html")

    # b) Bridge de GPS: lê navigator.geolocation no MAIN THREAD e publica via BroadcastChannel
    # com suporte a Background Keep-Alive e atualização instantânea ao sair do Waze
    gps_bridge = """<script>
(function(){
  try {
    if (!('geolocation' in navigator)) return;
    var bc = new BroadcastChannel('smartfrota_gps');
    
    // 1. Background Keep-Alive via audio silencioso em loop
    // Mantem o worker e a escuta do GPS ativos em segundo plano (ex.: motorista usando Waze)
    var bgAudio = null;
    function startBgKeepAlive() {
      try {
        if (!bgAudio) {
          bgAudio = document.createElement('audio');
          bgAudio.src = 'data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA';
          bgAudio.loop = true;
          bgAudio.volume = 0.01;
        }
        bgAudio.play().catch(function(){});
      } catch(e) {}
      try {
        if ('wakeLock' in navigator && !window._smartWakeLock) {
          navigator.wakeLock.request('screen').then(function(lock){ window._smartWakeLock = lock; }).catch(function(){});
        }
      } catch(e) {}
    }
    document.addEventListener('click', startBgKeepAlive);
    document.addEventListener('touchstart', startBgKeepAlive);

    // 2. watchPosition continuo de alta precisao
    var watchOptions = { enableHighAccuracy: true, timeout: 10000, maximumAge: 3000 };
    function onPos(pos) {
      try {
        bc.postMessage({
          lat: pos.coords.latitude,
          lon: pos.coords.longitude,
          accuracy: pos.coords.accuracy,
          speed: pos.coords.speed,
          heading: pos.coords.heading,
          timestamp: pos.timestamp
        });
      } catch(e) {}
    }
    navigator.geolocation.watchPosition(onPos, function(err){}, watchOptions);

    // 3. Ao retornar para o app (visibilidade restabelecida ao sair do Waze)
    // Forca leitura imediata de posicao fresca para atualizacao instantanea
    document.addEventListener('visibilitychange', function() {
      if (document.visibilityState === 'visible') {
        startBgKeepAlive();
        navigator.geolocation.getCurrentPosition(function(pos) {
          try {
            bc.postMessage({
              lat: pos.coords.latitude,
              lon: pos.coords.longitude,
              accuracy: pos.coords.accuracy,
              wake: true
            });
          } catch(e) {}
        }, function(err){}, { enableHighAccuracy: true, timeout: 6000, maximumAge: 0 });
      }
    });
  } catch(e) {
    console.log('GPS bridge error', e);
  }
})();
</script>"""
    if "smartfrota_gps" not in content:
        if "</body>" in content:
            content = content.replace("</body>", gps_bridge + "</body>")
            print("GPS bridge injetado no index.html!")
        elif "</head>" in content:
            content = content.replace("</head>", gps_bridge + "</head>")
            print("GPS bridge injetado no index.html (head)!")
        else:
            print("Aviso: ponto de injecao do GPS bridge nao encontrado no index.html")
    else:
        print("GPS bridge ja presente no index.html.")

    # c) Branding: título, descrição e cores do app
    branding = {
        '<title>Flet</title>': f'<title>{app_name}</title>',
        '<title>SmartFrota</title>': f'<title>{app_name}</title>',
        '<meta name="description" content="Flet application.">':
            f'<meta name="description" content="{app_desc}">',
        '<meta name="apple-mobile-web-app-title" content="Flet">':
            f'<meta name="apple-mobile-web-app-title" content="{app_name}">',
        '<meta name="apple-mobile-web-app-title" content="SmartFrota">':
            f'<meta name="apple-mobile-web-app-title" content="{app_name}">',
    }
    for old, new in branding.items():
        if old in content:
            content = content.replace(old, new)
    
    if '<meta name="theme-color"' in content:
        content = re.sub(r'<meta name="theme-color" content="[^"]*">', f'<meta name="theme-color" content="{theme_color}">', content)
    else:
        content = content.replace('</head>', f'<meta name="theme-color" content="{theme_color}">\n</head>', 1)

    with open(index_path, "w", encoding="utf-8") as f:
        f.write(content)
else:
    print("Erro: index.html nao encontrado!")

# 3. Patch manifest.json (nome e cores do PWA)
manifest_path = os.path.join("dist", "manifest.json")
if os.path.exists(manifest_path):
    with open(manifest_path, "r", encoding="utf-8") as f:
        manifest = json.load(f)

    manifest["name"] = app_name
    manifest["short_name"] = app_short
    manifest["description"] = app_desc
    manifest["theme_color"] = theme_color
    manifest["background_color"] = "#0F172A"

    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False)
    print(f"manifest.json atualizado ({app_name} - tema {theme_color}).")
else:
    print("Erro: manifest.json nao encontrado!")

# 4. Copia assets do app (ex.: logo da tela de login) para dist/assets/
assets_src = os.path.join("assets")
assets_dst = os.path.join("dist", "assets")
if os.path.isdir(assets_src):
    os.makedirs(assets_dst, exist_ok=True)
    for name in os.listdir(assets_src):
        src_path = os.path.join(assets_src, name)
        if os.path.isfile(src_path):
            shutil.copy2(src_path, os.path.join(assets_dst, name))
    print("Assets do app copiados para dist/assets/.")
else:
    print("Aviso: pasta assets/ nao encontrada (logo de login nao sera copiada).")

# 5. Patch flutter_bootstrap.js (serviceWorkerVersion no entrypoint moderno do Flutter Web)
bootstrap_path = os.path.join("dist", "flutter_bootstrap.js")
if os.path.exists(bootstrap_path):
    with open(bootstrap_path, "r", encoding="utf-8") as f:
        b_content = f.read()
    b_content, b_count = re.subn(r'serviceWorkerVersion:\s*"\d+"', f'serviceWorkerVersion: "{int(time.time())}"', b_content)
    if b_count > 0:
        with open(bootstrap_path, "w", encoding="utf-8") as f:
            f.write(b_content)
        print("serviceWorkerVersion atualizado no flutter_bootstrap.js!")

# 6. Recalcula hashes MD5 dos arquivos alterados dentro do flutter_service_worker.js
sw_path = os.path.join("dist", "flutter_service_worker.js")
if os.path.exists(sw_path):
    import hashlib
    with open(sw_path, "r", encoding="utf-8") as f:
        sw_content = f.read()

    sw_updated = False
    for fname in ["index.html", "python-worker.js", "manifest.json", "flutter_bootstrap.js"]:
        fpath = os.path.join("dist", fname)
        if os.path.exists(fpath):
            with open(fpath, "rb") as f:
                new_hash = hashlib.md5(f.read()).hexdigest()
            pattern = rf'"{re.escape(fname)}":\s*"[a-f0-9]+"'
            if re.search(pattern, sw_content):
                sw_content = re.sub(pattern, f'"{fname}": "{new_hash}"', sw_content)
                sw_updated = True

    if sw_updated:
        with open(sw_path, "w", encoding="utf-8") as f:
            f.write(sw_content)
        print("Hashes de integridade atualizados em flutter_service_worker.js!")
