import sqlite3

DB='local_cache.db'
conn=sqlite3.connect(DB)
cur=conn.cursor()
print('=== Users ===')
for r in cur.execute("SELECT id,nome,empresa_id,veiculo_id FROM sf_local_usuarios ORDER BY nome ASC"):
    print(r)

# Find demo user by name or known id
print('\n=== Searching for users named Demo ===')
cur.execute("SELECT id,nome FROM sf_local_usuarios WHERE nome LIKE '%Demo%'")
rows=cur.fetchall()
print(rows)

for row in rows:
    uid=row[0]
    print(f"\n--- Last diarios for user {row[1]} ({uid}) ---")
    cur.execute("SELECT id,nome_evento,data_hora,km_atual,km_breadcrumbs,latitude,longitude FROM sf_local_diarios WHERE usuario_id=? ORDER BY data_hora DESC LIMIT 10",(uid,))
    for r in cur.fetchall():
        print('diario:',r)
    print(f"\n--- Last macros for user {row[1]} ({uid}) ---")
    cur.execute("SELECT id,evento_nome,data_hora,km_atual FROM sf_local_macros WHERE usuario_id=? ORDER BY data_hora DESC LIMIT 10",(uid,))
    for r in cur.fetchall():
        print('macro:',r)

print('\n=== Computed last_km per user (local logic) ===')
cur.execute("SELECT id,nome FROM sf_local_usuarios ORDER BY nome ASC")
for uid,name in cur.fetchall():
    km = 0.0
    t_diario = None
    t_macro = None
    cur.execute("SELECT km_atual,data_hora FROM sf_local_diarios WHERE usuario_id=? AND km_atual IS NOT NULL ORDER BY data_hora DESC LIMIT 1",(uid,))
    r = cur.fetchone()
    if r:
        km_d = float(r[0])
        t_diario = r[1]
    else:
        km_d = 0.0
    cur.execute("SELECT km_atual,data_hora FROM sf_local_macros WHERE usuario_id=? AND km_atual IS NOT NULL ORDER BY data_hora DESC LIMIT 1",(uid,))
    r = cur.fetchone()
    if r:
        km_m = float(r[0])
        t_macro = r[1]
    else:
        km_m = 0.0
    # choose most recent
    chosen = 0.0
    if t_diario and (not t_macro or t_diario >= t_macro):
        chosen = km_d
    elif t_macro:
        chosen = km_m
    print(f'{name} ({uid}) -> last_km = {chosen}')

conn.close()
