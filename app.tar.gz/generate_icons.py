#!/usr/bin/env python3
"""Gera os ícones e imagens do SmartFrota (substitui os padrões do Flet).

Design: pino de localização sobre uma rota, com fundo em gradiente.
- Homologação: Fundo Laranja (#FB923C -> #C2410C)
- Produção:    Fundo Azul    (#3B82F6 -> #1E3A8A)

Saída: dist/favicon.png e dist/icons/*.png

Requer: Pillow (pip install pillow)
"""
import os
import sys
import argparse
from PIL import Image, ImageDraw, ImageChops

THEMES = {
    "prod": {
        "top": (59, 130, 246),      # #3B82F6
        "bottom": (30, 58, 138),    # #1E3A8A
        "theme_color": "#2563EB",
        "route_svg": "#60A5FA",
        "name": "Produção (Azul)"
    },
    "homolog": {
        "top": (251, 146, 60),      # #FB923C
        "bottom": (194, 65, 12),    # #C2410C
        "theme_color": "#EA580C",
        "route_svg": "#FB923C",
        "name": "Homologação (Laranja)"
    }
}

WHITE = (255, 255, 255)
OUT_DIR = os.path.join("dist")


def rounded_gradient(size, radius, top, bottom):
    """Fundo quadrado arredondado com gradiente vertical."""
    grad = Image.new("RGB", (1, size))
    for y in range(size):
        t = y / max(size - 1, 1)
        grad.putpixel((0, y), (
            int(top[0] + (bottom[0] - top[0]) * t),
            int(top[1] + (bottom[1] - top[1]) * t),
            int(top[2] + (bottom[2] - top[2]) * t),
        ))
    grad = grad.resize((size, size), Image.LANCZOS)
    mask = Image.new("L", (size, size), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, size - 1, size - 1], radius=radius, fill=255)
    out = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    out.paste(grad.convert("RGBA"), (0, 0), mask)
    return out


def pin_road_layer(transparent_hole=True):
    """Desenha o pino + rota (branco) em camada transparente, em 1024x1024."""
    S = 1024
    layer = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)

    # Rota (linha horizontal, cantos arredondados)
    d.line([(150, 640), (874, 640)], fill=WHITE + (255,), width=48, joint="curve")

    # Pino: círculo + triângulo (cauda)
    cx, cy, r = 512, 420, 160
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=WHITE + (255,))
    d.polygon([(368, 430), (656, 430), (512, 640)], fill=WHITE + (255,))

    if transparent_hole:
        # Furo central transparente (deixa o gradiente aparecer)
        hole = Image.new("L", (S, S), 0)
        ImageDraw.Draw(hole).ellipse([cx - 68, cy - 68, cx + 68, cy + 68], fill=255)
        layer.putalpha(ImageChops.subtract(layer.getchannel("A"), hole))
    return layer


def build_icon(size, top, bottom, maskable=False):
    radius = 0 if maskable else int(size * 0.22)
    img = rounded_gradient(size, radius, top, bottom)

    design = pin_road_layer()
    if maskable:
        target = int(size * 0.74)  # zona segura dos ícones maskable (~80%)
        design = design.resize((target, target), Image.LANCZOS)
        offset = (size - target) // 2
        img.alpha_composite(design, (offset, offset))
    else:
        design = design.resize((size, size), Image.LANCZOS)
        img.alpha_composite(design, (0, 0))
    return img


def build_loading(size=512):
    """Imagem de loading: pino branco sobre fundo transparente (mostra sobre o splash)."""
    layer = pin_road_layer(transparent_hole=True)
    return layer.resize((size, size), Image.LANCZOS)


def build_launcher(size, top, bottom):
    """Ícone de launcher full-bleed (sem transparência nas bordas), para flet build."""
    img = rounded_gradient(size, 0, top, bottom)  # radius 0 = quadrado cheio
    design = pin_road_layer(transparent_hole=True)
    design = design.resize((size, size), Image.LANCZOS)
    img.alpha_composite(design, (0, 0))
    return img.convert("RGB")


def generate_svg_icon(env_name, route_color):
    """Gera SVG para a tela de login condizente com o ambiente."""
    assets_dist = os.path.join(OUT_DIR, "assets")
    os.makedirs(assets_dist, exist_ok=True)
    svg_content = f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="200" height="200">
  <!-- Rota -->
  <path d="M22 140 H178" stroke="{route_color}" stroke-width="13" stroke-linecap="round"/>
  <!-- Pino de localizacao -->
  <circle cx="100" cy="88" r="50" fill="#FFFFFF"/>
  <path d="M66 92 L134 92 L100 146 Z" fill="#FFFFFF"/>
  <circle cx="100" cy="88" r="21" fill="#0F172A"/>
</svg>
"""
    with open(os.path.join(assets_dist, "smartfrota_icon.svg"), "w", encoding="utf-8") as f:
        f.write(svg_content)


def main():
    parser = argparse.ArgumentParser(description="Gerador de ícones SmartFrota")
    parser.add_argument("--env", choices=["prod", "homolog"], default="homolog",
                        help="Ambiente de destino: 'homolog' (laranja) ou 'prod' (azul)")
    args = parser.parse_args()

    theme = THEMES.get(args.env, THEMES["homolog"])
    top = theme["top"]
    bottom = theme["bottom"]

    # Ícones de launcher (usados pelo `flet build apk/ipa/desktop`) — sempre gerados
    assets_dir = "assets"
    os.makedirs(assets_dir, exist_ok=True)
    build_launcher(1024, top, bottom).save(os.path.join(assets_dir, "icon.png"))
    build_launcher(1024, top, bottom).save(os.path.join(assets_dir, "icon_android.png"))
    build_launcher(1024, top, bottom).save(os.path.join(assets_dir, "icon_ios.png"))
    build_launcher(512, top, bottom).save(os.path.join(assets_dir, "icon_web.png"))
    build_launcher(1024, top, bottom).save(os.path.join(assets_dir, "icon_macos.png"))
    build_launcher(256, top, bottom).save(os.path.join(assets_dir, "icon_windows.png"))
    print(f"Ícones de launcher gerados em {assets_dir}/ [{theme['name']}]")

    if not os.path.isdir(OUT_DIR):
        print(f"Aviso: pasta '{OUT_DIR}' não encontrada — ícones PWA ignorados (rode após 'flet publish').")
        return

    icons_dir = os.path.join(OUT_DIR, "icons")
    os.makedirs(icons_dir, exist_ok=True)

    # Ícones PWA
    build_icon(192, top, bottom).save(os.path.join(icons_dir, "icon-192.png"))
    build_icon(512, top, bottom).save(os.path.join(icons_dir, "icon-512.png"))
    build_icon(192, top, bottom, maskable=True).save(os.path.join(icons_dir, "icon-maskable-192.png"))
    build_icon(512, top, bottom, maskable=True).save(os.path.join(icons_dir, "icon-maskable-512.png"))

    # iOS apple-touch-icon (com fundo, sem transparência)
    build_icon(192, top, bottom).convert("RGB").save(os.path.join(icons_dir, "apple-touch-icon-192.png"))

    # Favicon (browser)
    build_icon(32, top, bottom).save(os.path.join(OUT_DIR, "favicon.png"))

    # Imagem de loading (splash)
    build_loading(512).save(os.path.join(icons_dir, "loading-animation.png"))

    # SVG da tela de login
    generate_svg_icon(args.env, theme["route_svg"])

    print(f"Ícones SmartFrota gerados com sucesso [{theme['name']}] em {OUT_DIR}")


if __name__ == "__main__":
    main()
