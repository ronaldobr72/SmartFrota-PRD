import flet as ft
from datetime import datetime, timedelta, timezone
import random
import database as db
import asyncio
import math
import time

# GPS nativo (Android/iOS) via flet-geolocator.
# No navegador (PWA/Pyodide) o pacote não está disponível e o app usa o
# navigator.geolocation (js) — veja _install_gps_watch().
try:
    from flet_geolocator import Geolocator
    GEOLOCATOR_AVAILABLE = True
except Exception:
    GEOLOCATOR_AVAILABLE = False

# Versão visível do app (exibida na tela de login e no info do Android).
# Incremente a cada release para facilitar a identificação do build instalado.
APP_VERSION = "1.1.1"

# Fuso horário local (America/Sao_Paulo — sem horário de verão desde 2019)
LOCAL_TZ = timezone(timedelta(hours=-3), name="America/Sao_Paulo")

def _format_local(dt_str):
    """Converte timestamp ISO (UTC) para horário local de Brasília."""
    try:
        dt = datetime.fromisoformat(dt_str.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(LOCAL_TZ).strftime("%d/%m %H:%M")
    except Exception:
        return dt_str or ""

def _local_day_start_utc(days_ago=0):
    """Início do dia local (America/Sao_Paulo) convertido para UTC (ISO)."""
    local_now = datetime.now(LOCAL_TZ)
    local_midnight = (local_now - timedelta(days=days_ago)).replace(hour=0, minute=0, second=0, microsecond=0)
    return local_midnight.astimezone(timezone.utc).isoformat()

# Buffer compartilhado com o callback JS de geolocalização (navegador/Pyodide)
GPS_BUFFER = {}

def _install_gps_watch():
    """Instala a leitura de GPS real do dispositivo (navegador/PWA).

    Estratégia em duas camadas:
    1. BroadcastChannel "smartfrota_gps": recebe a posição lida no MAIN THREAD
       (script injetado no index.html), funcionando em Chrome, Firefox e Safari.
    2. Fallback: navigator.geolocation diretamente no Web Worker (Chrome/Android).
    """
    import sys
    if sys.platform != "emscripten":
        return False
    try:
        import js
        from pyodide.ffi import create_proxy
        installed = False

        def _save(lat, lon, accuracy=None):
            GPS_BUFFER["lat"] = float(lat)
            GPS_BUFFER["lon"] = float(lon)
            if accuracy is not None:
                GPS_BUFFER["accuracy"] = float(accuracy)
            else:
                GPS_BUFFER.pop("accuracy", None)
            GPS_BUFFER["error"] = None

        # 1) BroadcastChannel (main thread -> worker)
        try:
            bc = js.BroadcastChannel.new("smartfrota_gps")
            def on_bc_msg(evt):
                data = evt.data
                if data:
                    acc = None
                    try:
                        acc = data.accuracy
                    except Exception:
                        acc = None
                    _save(data.lat, data.lon, acc)
                    try:
                        if getattr(data, "wake", False) or (isinstance(data, dict) and data.get("wake")):
                            GPS_BUFFER["wake"] = True
                    except Exception:
                        pass
            bc.onmessage = create_proxy(on_bc_msg)
            installed = True
            print("GPS: BroadcastChannel instalado (main thread).")
        except Exception as e:
            print(f"GPS: BroadcastChannel indisponível: {e}")

        # 2) Fallback: geolocation direta no worker
        try:
            geo = js.navigator.geolocation
            if geo is not None:
                def on_success(pos):
                    acc = None
                    try:
                        acc = pos.coords.accuracy
                    except Exception:
                        acc = None
                    _save(pos.coords.latitude, pos.coords.longitude, acc)
                def on_error(err):
                    GPS_BUFFER["error"] = getattr(err, "message", None) or str(err)
                opts = js.Object.new()
                opts.enableHighAccuracy = True
                opts.timeout = 10000
                opts.maximumAge = 5000
                geo.watchPosition(create_proxy(on_success), create_proxy(on_error), opts)
                installed = True
                print("GPS: watchPosition instalado (worker).")
        except Exception as e:
            print(f"GPS: watchPosition indisponível: {e}")

        return installed
    except Exception as e:
        print(f"GPS: falha ao instalar: {e}")
        return False

# Configurações de design moderno (Aesthetics)
BG_COLOR = "#0F172A"       # Slate 900
SURFACE_COLOR = "#1E293B"  # Slate 800
SURFACE_LIGHT = "#334155"  # Slate 700
PRIMARY_COLOR = "#3B82F6"  # Blue 500
ACCENT_COLOR = "#10B981"   # Emerald 500
WARNING_COLOR = "#F59E0B"  # Amber 500
TEXT_COLOR = "#F8FAFC"     # Slate 50
TEXT_MUTED = "#94A3B8"     # Slate 400

# Eventos diários disponíveis
DIARIOS_EVENTOS = [
    "Retirada na garagem",
    "Chegada ao primeiro aluno",
    "Chegada a última escola",
    "Chegada a área de descanso",
    "Retorno a garagem principal",
    "Deslocamento não programado"
]

async def main(page: ft.Page):
    page.title = "SmartFrota - Motorista"
    page.theme_mode = ft.ThemeMode.DARK
    page.bgcolor = BG_COLOR
    page.padding = 0
    page.window.width = 410
    page.window.height = 820
    page.window.resizable = True

    # Demo Accounts simulating Multi-user and Multi-company
    DEMO_ACCOUNTS = [
        {"empresa": "Empresa Demo", "empresa_id": "demo-empresa-1", "usuario": "Motorista Demo 1", "usuario_id": "demo-usuario-1", "senha": "demo123"},
        {"empresa": "Empresa Demo", "empresa_id": "demo-empresa-1", "usuario": "Motorista Demo 2", "usuario_id": "demo-usuario-2", "senha": "demo123"},
        {"empresa": "Empresa Demo", "empresa_id": "demo-empresa-1", "usuario": "Motorista Demo 3", "usuario_id": "demo-usuario-3", "senha": "demo123"},
    ]

    # State variables
    current_driver = None
    current_driver_id = None
    current_empresa_id = None
    last_daily_event = None
    daily_events_list = []
    macro_configs = []
    daily_configs = []
    current_vehicle = None
    is_online = True
    pending_sync_count = 0
    last_km = 0.0
    km_edited = False       # Indica que o usuário alterou manualmente o campo KM diário
    km_macro_edited = False # Indica que o usuário alterou manualmente o campo KM macro

    # UI References e Callbacks
    status_badge_ref = None
    sync_banner_ref = None
    load_timeline_events_ref = None
    km_input_ref = None
    km_macro_input_ref = None
    breadcrumbs_label_ref = None
    breadcrumbs_macro_label_ref = None
    last_event_label_ref = None
    event_dropdown_ref = None

    # Virtual odometer variables
    current_breadcrumbs_distance = 0.0
    last_gps_lat = -23.683500 # Default para a localização real do usuário em São Bernardo do Campo
    last_gps_lon = -46.555300

    lat_input_ctrl = None
    lon_input_ctrl = None
    simular_movimento = False
    simular_movimento_switch_ref = None
    update_sandbox_visibility_ref = None
    current_timeline_days = 1
    last_event_label_ref = None
    dashboard_active = False
    _last_progress_save = 0.0
    gap_seed_done = False
    first_fix_done = False

    # --- Utilitários de conversão numérica e Odômetro Virtual ---
    def to_float_safe(val, default=0.0):
        """Converte valor numérico para float de forma segura, aceitando vírgula ou ponto."""
        if val is None:
            return default
        if isinstance(val, (int, float)):
            return float(val)
        try:
            clean = str(val).strip().replace(',', '.')
            return float(clean) if clean else default
        except (ValueError, TypeError):
            return default

    # --- Captura de KMs percorridos (trilha de pão / breadcrumbs) ---
    MIN_DIST_KM = 0.02    # 20 metros (filtra ruído do GPS com o veículo parado)
    MIN_SPEED_KMH = 2.0   # 2 km/h
    ACCURACY_LIMIT_M = 50.0  # metros — ignora posições mais imprecisas que isso

    def haversine_km(lat1, lon1, lat2, lon2):
        """Distância em km entre dois pontos (fórmula de Haversine)."""
        dlat = math.radians(lat2 - lat1)
        dlon = math.radians(lon2 - lon1)
        a = math.sin(dlat / 2) ** 2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon / 2) ** 2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(max(0.0, 1 - a)))
        return 6371.0 * c

    def accumulate_gps_movement(new_lat, new_lon, interval_seconds):
        """Registra um novo ponto GPS e acumula a distância percorrida (trilha de pão).

        Filtra jitter (movimentos < MIN_DIST_KM ou velocidade < MIN_SPEED_KMH)
        para não inflar o odômetro com ruído do GPS.
        Retorna a distância adicionada em km.
        """
        nonlocal current_breadcrumbs_distance, last_gps_lat, last_gps_lon
        dist = haversine_km(last_gps_lat, last_gps_lon, new_lat, new_lon)
        speed_kmh = (dist / (interval_seconds / 3600.0)) if interval_seconds > 0 else 0.0

        last_gps_lat = new_lat
        last_gps_lon = new_lon

        if dist < MIN_DIST_KM or speed_kmh < MIN_SPEED_KMH:
            persist_progress()
            return 0.0

        current_breadcrumbs_distance += dist
        persist_progress()
        return dist

    def get_traveled_km_since_last_record():
        """KMs percorridos desde o último registro (trilha de pão acumulada)."""
        return current_breadcrumbs_distance

    def compute_gap_from_last_event(current_lat, current_lon):
        """Distância (km) entre o último evento diário registrado e a posição atual.

        Usada quando o app volta de segundo plano (ex.: motorista no Waze)
        ou é reaberto sem trilha de pão completa, calculando o deslocamento real.
        """
        if current_lat is None or current_lon is None:
            return None
        # 1. Procura na lista de eventos diários em memória (do mais recente ao mais antigo)
        if daily_events_list:
            for ev in reversed(daily_events_list):
                lat = ev.get("latitude")
                lon = ev.get("longitude")
                if lat is not None and lon is not None:
                    try:
                        return haversine_km(float(lat), float(lon), float(current_lat), float(current_lon))
                    except (ValueError, TypeError):
                        pass
        # 2. Fallback: consulta diretamente os eventos diários salvos no SQLite local
        try:
            evs = db.get_daily_events(empresa_id=current_empresa_id, usuario_id=current_driver_id)
            if evs:
                for ev in reversed(evs):
                    lat = ev.get("latitude")
                    lon = ev.get("longitude")
                    if lat is not None and lon is not None:
                        try:
                            return haversine_km(float(lat), float(lon), float(current_lat), float(current_lon))
                        except (ValueError, TypeError):
                            pass
        except Exception as e:
            print(f"Erro ao buscar último evento para gap: {e}")
        return None

    def update_gps_fields():
        if lat_input_ctrl and lon_input_ctrl:
            lat_input_ctrl.value = f"{last_gps_lat:.6f}"
            lon_input_ctrl.value = f"{last_gps_lon:.6f}"

    def update_breadcrumb_labels():
        txt = f"KMs percorridos desde o último registro: {current_breadcrumbs_distance:.2f} km"
        if breadcrumbs_label_ref:
            breadcrumbs_label_ref.value = txt
        if breadcrumbs_macro_label_ref:
            breadcrumbs_macro_label_ref.value = txt
        
        # Atualiza a sugestão de KM em tempo real caso o usuário não tenha travado a edição manual
        suggested_km = last_km + current_breadcrumbs_distance
        if km_input_ref is not None and not km_edited:
            km_input_ref.value = f"{suggested_km:.2f}"
        if km_macro_input_ref is not None and not km_macro_edited:
            km_macro_input_ref.value = f"{suggested_km:.2f}"

    def update_km_fields():
        """Atualiza os campos de KM com o odômetro automático:
        último KM registrado + kms percorridos desde o último registro.
        Respeita a trava de edição manual (km_edited / km_macro_edited)."""
        auto_km = last_km + current_breadcrumbs_distance
        if km_input_ref is not None and not km_edited:
            km_input_ref.value = f"{auto_km:.2f}"
        if km_macro_input_ref is not None and not km_macro_edited:
            km_macro_input_ref.value = f"{auto_km:.2f}"

    def persist_progress(force=False):
        """Salva o progresso da jornada para recuperação caso o app seja fechado/trave."""
        nonlocal _last_progress_save
        if not dashboard_active or not current_driver_id:
            return
        now = time.monotonic()
        if not force and (now - _last_progress_save) < 5.0:
            return
        _last_progress_save = now
        try:
            db.save_driver_progress(
                usuario_id=current_driver_id,
                km_breadcrumbs=current_breadcrumbs_distance,
                last_lat=last_gps_lat,
                last_lon=last_gps_lon,
                km_atual=last_km,
                km_edited=1 if km_edited else 0,
                km_macro_edited=1 if km_macro_edited else 0,
                force_sync=force
            )
        except Exception as e:
            print(f"Erro ao persistir progresso: {e}")

    async def gps_simulator():
        interval = 6  # segundos; manter sincronizado com await.sleep

        while True:
            await asyncio.sleep(interval)  # Movimenta o GPS virtual a cada 6 segundos

            if not simular_movimento:
                continue

            # Simula deslocamento realista de van (passo pequeno ~ velocidade urbana)
            step_lat = random.uniform(-0.0005, 0.0005)
            step_lon = random.uniform(-0.0005, 0.0005)
            new_lat = last_gps_lat + step_lat
            new_lon = last_gps_lon + step_lon

            accumulate_gps_movement(new_lat, new_lon, interval)
            update_gps_fields()
            update_breadcrumb_labels()
            update_km_fields()
            page.update()


    # Sequential event helper
    def get_next_sequential_event():
        if daily_configs:
            seq_configs = [cfg["nome"] for cfg in daily_configs if cfg.get("participa_sequencia", 1) == 1]
        else:
            seq_configs = [e for e in DIARIOS_EVENTOS if e != "Deslocamento não programado"]
        if not seq_configs:
            seq_configs = [cfg["nome"] for cfg in daily_configs] if daily_configs else list(DIARIOS_EVENTOS)
        
        # Procura o último evento registrado que faça parte da sequência
        target_last = last_daily_event
        if target_last not in seq_configs and daily_events_list:
            for ev in reversed(daily_events_list):
                if ev.get("nome_evento") in seq_configs:
                    target_last = ev.get("nome_evento")
                    break

        last_index = -1
        for idx, nome in enumerate(seq_configs):
            if nome == target_last:
                last_index = idx
                break
        if last_index == -1 or last_index == len(seq_configs) - 1:
            return seq_configs[0]
        return seq_configs[last_index + 1]

    # Carga de dados iniciais
    def load_initial_data():
        nonlocal last_daily_event, daily_events_list, macro_configs, daily_configs, current_vehicle, is_online, pending_sync_count, last_km, km_edited, km_macro_edited, current_breadcrumbs_distance, last_gps_lat, last_gps_lon
        # A cada carga de dados, os campos de KM voltam a aceitar atualização automática
        # (o usuário ainda não editou nada nesta nova tela/sessão)
        km_edited = False
        km_macro_edited = False
        if not current_driver_id:
            return
        try:
            # Pega o contador de itens não sincronizados localmente (sem fazer chamada de rede)
            pending_sync_count = db.get_unsynced_count()

            # Pega eventos do dia de hoje filtrados pela empresa e motorista logado
            # Início do dia local (America/Sao_Paulo) convertido para UTC
            today_start = _local_day_start_utc(0)
            events = db.get_daily_events(start_date=today_start, empresa_id=current_empresa_id, usuario_id=current_driver_id)
            daily_events_list = events
            if events:
                last_daily_event = events[-1]["nome_evento"]
            else:
                # Fallback: se ainda não há eventos hoje, recupera o último evento histórico do motorista
                # para que o próximo evento da sequência em loop continue de onde parou
                all_prev = db.get_daily_events(empresa_id=current_empresa_id, usuario_id=current_driver_id)
                last_daily_event = all_prev[-1]["nome_evento"] if all_prev else None

            macro_configs = db.get_usuario_event_configs(current_driver_id, "macro")
            daily_configs = db.get_usuario_event_configs(current_driver_id, "diario")
            
            if not macro_configs:
                macro_configs = [c for c in db.get_event_configs(empresa_id=current_empresa_id) if c.get("tipo") == "macro"]
            if not daily_configs:
                daily_configs = [c for c in db.get_event_configs(empresa_id=current_empresa_id) if c.get("tipo") == "diario"]
            
            current_vehicle = db.get_driver_veiculo(current_driver_id)
            
            # Recuperar KM anterior do banco
            db_km = db.get_last_registered_km(empresa_id=current_empresa_id, usuario_id=current_driver_id)
            last_km = float(db_km) if db_km is not None else 0.0

            # Restaura o progresso da jornada (trilha de pão + flags de edição),
            # caso o app tenha sido fechado/travado no meio do percurso.
            try:
                progress = db.get_driver_progress(current_driver_id)
                if progress:
                    if progress.get("km_breadcrumbs") is not None:
                        current_breadcrumbs_distance = float(progress["km_breadcrumbs"])
                    if progress.get("last_lat") is not None and progress.get("last_lon") is not None:
                        last_gps_lat = float(progress["last_lat"])
                        last_gps_lon = float(progress["last_lon"])
                    km_edited = bool(progress.get("km_edited"))
                    km_macro_edited = bool(progress.get("km_macro_edited"))
                    # Se havia edição manual pendente, restaura o valor digitado
                    if (km_edited or km_macro_edited) and progress.get("km_atual") is not None:
                        last_km = float(progress["km_atual"])
            except Exception as e:
                print(f"Erro ao restaurar progresso do motorista: {e}")
        except Exception as e:
            print(f"Erro ao carregar dados: {e}")

    # --- TELA DE CARREGAMENTO (SPLASH / PROGRESS) ---
    def show_loading_screen(message="Iniciando SmartFrota..."):
        nonlocal dashboard_active
        dashboard_active = False
        page.views.clear()
        page.views.append(
            ft.View(
                "/loading",
                [
                    ft.Container(
                        content=ft.Column(
                            [
                                ft.Image(src="assets/smartfrota_icon.svg", width=85, height=85),
                                ft.Text("SmartFrota", size=30, weight=ft.FontWeight.BOLD, color=TEXT_COLOR),
                                ft.Text("Gestão Inteligente de Rotas", size=13, color=TEXT_MUTED),
                                ft.Divider(height=35, color=ft.colors.TRANSPARENT),
                                ft.ProgressRing(width=40, height=40, stroke_width=4, color=PRIMARY_COLOR),
                                ft.Divider(height=15, color=ft.colors.TRANSPARENT),
                                ft.Text(message, size=14, color=TEXT_COLOR, weight=ft.FontWeight.W_500, text_align=ft.TextAlign.CENTER),
                            ],
                            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                            alignment=ft.MainAxisAlignment.CENTER,
                        ),
                        alignment=ft.alignment.center,
                        expand=True,
                        padding=30,
                        gradient=ft.LinearGradient(
                            begin=ft.alignment.top_center,
                            end=ft.alignment.bottom_center,
                            colors=[BG_COLOR, SURFACE_COLOR]
                        )
                    )
                ]
            )
        )
        page.update()

    # --- TELA DE LOGIN SIMPLES (SIMULAÇÃO MULTI-TENANT) ---
    def show_login():
        nonlocal DEMO_ACCOUNTS, dashboard_active
        dashboard_active = False
        page.views.clear()
        
        # Sincroniza os cadastros do Supabase para o banco local antes de listar
        # as contas. Assim, na 1ª execução (instalação nova) o login mostra as
        # contas reais em vez do fallback de demonstração.
        try:
            db.sincronizar_cadastros()
        except Exception as ex:
            print(f"Erro ao sincronizar cadastros no login: {ex}")

        # Tenta carregar as empresas e usuários dinamicamente do banco de dados
        try:
            real_empresas = db.get_empresas()
            real_usuarios = db.get_usuarios()
            emp_map = {e["id"]: e["nome"] for e in real_empresas}
            
            loaded_accounts = []
            for u in real_usuarios:
                if u.get("role") == "motorista":
                    emp_nome = emp_map.get(u["empresa_id"], "Empresa Desconhecida")
                    loaded_accounts.append({
                        "empresa": emp_nome,
                        "empresa_id": u["empresa_id"],
                        "usuario": u["nome"],
                        "usuario_id": u["id"],
                        "senha": u.get("senha")
                    })
            if loaded_accounts:
                DEMO_ACCOUNTS = loaded_accounts
        except Exception as ex:
            print(f"Erro ao carregar contas dinâmicas: {ex}")
            
        account_dropdown = ft.Dropdown(
            label="Selecione sua Conta (Demo)",
            label_style=ft.TextStyle(color=TEXT_MUTED),
            options=[ft.dropdown.Option(text=f"{acc['empresa']} ({acc['usuario']})", key=str(idx)) for idx, acc in enumerate(DEMO_ACCOUNTS)],
            value="0" if DEMO_ACCOUNTS else None,
            border_color=PRIMARY_COLOR,
            bgcolor=SURFACE_COLOR,
            color=TEXT_COLOR,
            width=300
        )

        password_input = ft.TextField(
            label="Senha de Acesso",
            label_style=ft.TextStyle(color=TEXT_MUTED),
            password=True,
            can_reveal_password=True,
            border_color=PRIMARY_COLOR,
            bgcolor=SURFACE_COLOR,
            color=TEXT_COLOR,
            width=300
        )
        
        def show_toast(msg, is_error=False):
            snack = ft.SnackBar(
                content=ft.Text(msg, color=TEXT_COLOR),
                bgcolor=ft.colors.RED_500 if is_error else ACCENT_COLOR
            )
            page.overlay.append(snack)
            snack.open = True
            page.update()

        
        async def handle_login(e):
            nonlocal current_driver, current_driver_id, current_empresa_id
            if not account_dropdown.value or int(account_dropdown.value) >= len(DEMO_ACCOUNTS):
                return
            acc = DEMO_ACCOUNTS[int(account_dropdown.value)]
            
            # Validação da senha: contas reais validam no servidor (RPC);
            # contas de demonstração/offline validam a senha local.
            entered_password = password_input.value
            if not entered_password:
                show_toast("Digite a senha!", True)
                return
            senha_local = acc.get("senha")
            if senha_local:
                senha_ok = (entered_password == senha_local)
            else:
                try:
                    senha_ok = await asyncio.to_thread(
                        db.autenticar_motorista, acc["usuario_id"], entered_password
                    )
                except Exception:
                    senha_ok = False
            if not senha_ok:
                show_toast("Senha incorreta!", True)
                return
                
            current_driver = acc["usuario"]
            current_driver_id = acc["usuario_id"]
            current_empresa_id = acc["empresa_id"]
            
            # Exibe carregamento enquanto salva e busca dados
            show_loading_screen(f"Carregando dados de {current_driver}...")
            
            # Salvar sessão persistente
            await page.client_storage.set_async("session_driver_id", current_driver_id)
            await page.client_storage.set_async("session_empresa_id", current_empresa_id)
            await page.client_storage.set_async("session_driver_nome", current_driver)
            
            # Sincroniza dados do motorista se estiver online
            try:
                is_on = await asyncio.to_thread(db.verificar_conexao) if hasattr(asyncio, "to_thread") else db.verificar_conexao()
                if is_on:
                    await asyncio.to_thread(db.atualizar_cache_local, current_driver_id) if hasattr(asyncio, "to_thread") else db.atualizar_cache_local(current_driver_id)
            except Exception as ex:
                print(f"Erro na sincronização de login: {ex}")

            login_success()

        login_btn = ft.ElevatedButton(
            "Entrar",
            style=ft.ButtonStyle(
                color=TEXT_COLOR,
                bgcolor=PRIMARY_COLOR,
                padding=15,
                shape=ft.RoundedRectangleBorder(radius=10)
            ),
            width=300,
            on_click=handle_login
        )

        page.views.append(
            ft.View(
                "/login",
                [
                    ft.Container(
                        content=ft.Column(
                            [
                                ft.Image(src="assets/smartfrota_icon.svg", width=80, height=80),
                                ft.Text("SmartFrota", size=32, weight=ft.FontWeight.BOLD, color=TEXT_COLOR),
                                ft.Text("Gestão Inteligente Multi-Empresa", size=14, color=TEXT_MUTED, text_align=ft.TextAlign.CENTER),
                                ft.Divider(height=40, color=ft.colors.TRANSPARENT),
                                account_dropdown,
                                password_input,
                                ft.Divider(height=10, color=ft.colors.TRANSPARENT),
                                login_btn,
                                ft.Divider(height=16, color=ft.colors.TRANSPARENT),
                                ft.Text(f"Versão {APP_VERSION}", size=12, color=TEXT_MUTED),
                            ],
                            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                            alignment=ft.MainAxisAlignment.CENTER,
                        ),
                        alignment=ft.alignment.center,
                        expand=True,
                        padding=30,
                        gradient=ft.LinearGradient(
                            begin=ft.alignment.top_center,
                            end=ft.alignment.bottom_center,
                            colors=[BG_COLOR, SURFACE_COLOR]
                        )
                    )
                ]
            )
        )
        page.update()

    def login_success():
        show_dashboard()

    # --- TELA PRINCIPAL (DASHBOARD) ---
    def show_dashboard():
        nonlocal dashboard_active
        dashboard_active = True
        load_initial_data()
        page.views.clear()

        # Feedback toast
        def show_toast(msg, is_error=False):
            snack = ft.SnackBar(
                content=ft.Text(msg, color=TEXT_COLOR),
                bgcolor=ft.colors.RED_500 if is_error else ACCENT_COLOR
            )
            page.overlay.append(snack)
            snack.open = True
            page.update()

        # Função para forçar sincronização
        async def trigger_sync(e):
            nonlocal is_online, pending_sync_count
            show_toast("Verificando conexão...")
            is_online = await asyncio.to_thread(db.verificar_conexao) if hasattr(asyncio, "to_thread") else db.verificar_conexao()
            if not is_online:
                show_toast("Sem conexão com a internet para sincronizar!", True)
                return
            
            show_toast("Sincronizando dados...")
            sincronizados, falhas = await asyncio.to_thread(db.sincronizar_dados_pendentes) if hasattr(asyncio, "to_thread") else db.sincronizar_dados_pendentes()
            await asyncio.to_thread(db.atualizar_cache_local, current_driver_id) if hasattr(asyncio, "to_thread") else db.atualizar_cache_local(current_driver_id)
            
            if sincronizados > 0:
                show_toast(f"{sincronizados} registro(s) sincronizados com sucesso!")
            elif falhas > 0:
                show_toast(f"Falha ao sincronizar {falhas} registro(s).", True)
            else:
                show_toast("Nenhum dado pendente de sincronização.")
                
            show_dashboard()

        # Salvar evento diário
        def save_daily(e):
            nonlocal current_breadcrumbs_distance, last_gps_lat, last_gps_lon, last_daily_event, event_dropdown, last_km, pending_sync_count, km_edited, km_macro_edited
            nome = event_dropdown.value
            km_raw = km_input.value
            lat_raw = lat_input.value
            lon_raw = lon_input.value

            if not nome:
                show_toast("Selecione um evento!", True)
                return
            if not km_raw or not str(km_raw).strip():
                show_toast("Digite o KM atual!", True)
                return
            
            try:
                km = to_float_safe(km_raw, default=None)
                if km is None:
                    raise ValueError()
                lat = to_float_safe(lat_raw, default=None) if (lat_raw and str(lat_raw).strip()) else None
                lon = to_float_safe(lon_raw, default=None) if (lon_raw and str(lon_raw).strip()) else None
            except ValueError:
                show_toast("KM e coordenadas devem ser números válidos!", True)
                return

            if last_daily_event == nome and nome not in ["Deslocamento não programado"]:
                show_toast(f"Não é permitido registrar '{nome}' seguidamente!", True)
                return

            # Obter último evento diário do motorista para calcular o snap-to-road
            snap_road_km = 0.0
            if daily_events_list:
                last_event = daily_events_list[-1]
                if last_event.get("latitude") and last_event.get("longitude") and lat and lon:
                    snap_road_km = db.get_osrm_distance(last_event["latitude"], last_event["longitude"], lat, lon)

            try:
                res = db.register_daily_event(
                    nome_evento=nome,
                    km_atual=km,
                    latitude=lat,
                    longitude=lon,
                    empresa_id=current_empresa_id,
                    usuario_id=current_driver_id,
                    km_breadcrumbs=get_traveled_km_since_last_record(),
                    km_snap_road=snap_road_km
                )
                show_toast("Evento registrado localmente!")
                # Atualiza último evento e seleciona próximo da sequência
                last_daily_event = nome
                
                # Registra o evento na lista de eventos de hoje em memória
                daily_events_list.append({
                    "id": res.get("id") if isinstance(res, dict) else None,
                    "nome_evento": nome,
                    "km_atual": float(km),
                    "latitude": float(lat) if lat is not None else None,
                    "longitude": float(lon) if lon is not None else None,
                    "data_hora": datetime.now(timezone.utc).isoformat()
                })

                next_ev = get_next_sequential_event()
                try:
                    event_dropdown.value = next_ev
                    if last_event_label_ref:
                        last_event_label_ref.value = f"Último evento: {last_daily_event}"
                except Exception:
                    pass
                # Atualiza o KM conhecido localmente para evitar campo vazio
                last_km = float(km)
                current_breadcrumbs_distance = 0.0
                # Ancora a trilha de pão na coordenada registrada, para que a
                # próxima medição comece exatamente no ponto marcado.
                if lat is not None and lon is not None:
                    last_gps_lat = float(lat)
                    last_gps_lon = float(lon)
                km_edited = False
                km_macro_edited = False
                gap_seed_done = False
                update_km_fields()
                update_breadcrumb_labels()
                persist_progress(force=True)
                # Atualiza contador de pendências e recarrega timeline para refletir o novo registro
                try:
                    pending_sync_count = db.get_unsynced_count()
                    if load_timeline_events_ref:
                        load_timeline_events_ref(1)
                except Exception:
                    pass
                page.update()
            except Exception as ex:
                show_toast(f"Erro ao salvar: {ex}", True)

        # Salvar evento macro
        def save_macro(e):
            nonlocal last_km, km_edited, km_macro_edited, current_breadcrumbs_distance
            nome = macro_dropdown.value
            km_raw = km_macro_input.value
            litros_raw = litros_input.value
            valor_litro_raw = valor_litro_input.value
            descricao = desc_input.value
            valor_total_manual = valor_total_input.value

            if not nome:
                show_toast("Selecione o tipo de evento macro!", True)
                return

            km_val = to_float_safe(km_raw, default=None) if (km_raw and str(km_raw).strip()) else None
            litros_val = to_float_safe(litros_raw, default=None) if (litros_raw and str(litros_raw).strip()) else None
            valor_litro_val = to_float_safe(valor_litro_raw, default=None) if (valor_litro_raw and str(valor_litro_raw).strip()) else None
            valor_total_val = to_float_safe(valor_total_manual, default=None) if (valor_total_manual and str(valor_total_manual).strip()) else None

            if nome == "Abastecimento":
                if km_val is None or litros_val is None or valor_litro_val is None:
                    show_toast("KM, Litros e Valor por Litro são obrigatórios no Abastecimento!", True)
                    return
                valor_total_val = litros_val * valor_litro_val

            try:
                db.register_macro_event(
                    evento_nome=nome,
                    km_atual=km_val,
                    litros=litros_val,
                    valor_por_litro=valor_litro_val,
                    descricao=descricao,
                    valor_total=valor_total_val,
                    empresa_id=current_empresa_id,
                    usuario_id=current_driver_id
                )
                show_toast("Evento despesa registrado localmente!")
                # Se o evento macro trouxe um KM, atualiza o KM local conhecido
                if km_val is not None:
                    try:
                        last_km = float(km_val)
                        current_breadcrumbs_distance = 0.0
                        km_edited = False
                        km_macro_edited = False
                        km_input.value = f"{last_km:.2f}"
                        km_macro_input.value = f"{last_km:.2f}"
                        update_breadcrumb_labels()
                    except Exception:
                        pass
                persist_progress(force=True)
                litros_input.value = ""
                valor_litro_input.value = ""
                desc_input.value = ""
                valor_total_input.value = ""
                try:
                    pending_sync_count = db.get_unsynced_count()
                    if sync_banner_ref:
                        sync_banner_ref.visible = (pending_sync_count > 0)
                        sync_banner_ref.content.controls[1].value = f"{pending_sync_count} registros pendentes offline"
                    if load_timeline_events_ref:
                        load_timeline_events_ref(current_timeline_days)
                except Exception:
                    pass
                page.update()
            except Exception as ex:
                show_toast(f"Erro ao salvar evento macro: {ex}", True)

        # Componentes visuais da rede / sincronização
        status_color = ACCENT_COLOR if is_online else WARNING_COLOR
        status_text = "Online" if is_online else "Offline"
        
        status_badge = ft.Container(
            content=ft.Row(
                [
                    ft.Container(width=10, height=10, bgcolor=status_color, border_radius=5),
                    ft.Text(status_text, color=TEXT_COLOR, size=14, weight=ft.FontWeight.BOLD)
                ],
                spacing=5
            ),
            bgcolor=SURFACE_COLOR,
            padding=ft.padding.all(8),
            border_radius=8
        )

        sync_banner = ft.Container(
            content=ft.Row(
                [
                    ft.Icon(ft.icons.SYNC_PROBLEM_ROUNDED, color=WARNING_COLOR, size=22),
                    ft.Text(f"{pending_sync_count} registros pendentes offline", color=TEXT_COLOR, weight=ft.FontWeight.W_500, expand=True),
                    ft.ElevatedButton("Sincronizar", icon=ft.icons.SYNC_ROUNDED, bgcolor=PRIMARY_COLOR, color=TEXT_COLOR, on_click=trigger_sync, style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=6)))
                ],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                vertical_alignment=ft.CrossAxisAlignment.CENTER
            ),
            bgcolor=SURFACE_COLOR,
            padding=ft.padding.symmetric(horizontal=14, vertical=10),
            border=ft.border.all(1, WARNING_COLOR),
            border_radius=10,
            visible=(pending_sync_count > 0)
        )

        nonlocal status_badge_ref, sync_banner_ref
        status_badge_ref = status_badge
        sync_banner_ref = sync_banner

        # Switch para forçar modo offline (apenas para testes)
        def on_force_offline_switch(e):
            nonlocal is_online
            try:
                db.set_force_offline(bool(e.control.value))
                # Atualiza indicador imediatamente
                is_online = not bool(e.control.value)
            except Exception:
                pass
            if status_badge_ref:
                status_badge_ref.content.controls[0].bgcolor = ACCENT_COLOR if is_online else WARNING_COLOR
                status_badge_ref.content.controls[1].value = "Online" if is_online else "Offline"
            page.update()

        force_offline_switch = ft.Switch(label="Forçar Offline (teste)", value=False, on_change=on_force_offline_switch, active_color=WARNING_COLOR)

        # Formulários
        event_dropdown = ft.Dropdown(
            label="Escolha o Evento do Dia a Dia",
            label_style=ft.TextStyle(color=TEXT_MUTED),
            options=[ft.dropdown.Option(cfg["nome"]) for cfg in daily_configs] if daily_configs else [ft.dropdown.Option(x) for x in DIARIOS_EVENTOS],
            bgcolor=SURFACE_COLOR,
            color=TEXT_COLOR,
            border_color=PRIMARY_COLOR,
            value=get_next_sequential_event()
        )
        nonlocal event_dropdown_ref
        event_dropdown_ref = event_dropdown

        initial_km = last_km if (km_edited or km_macro_edited) else (last_km + current_breadcrumbs_distance)

        km_input = ft.TextField(
            label="KM Atual da Van",
            label_style=ft.TextStyle(color=TEXT_MUTED),
            keyboard_type=ft.KeyboardType.NUMBER,
            border_color=PRIMARY_COLOR,
            color=TEXT_COLOR,
            bgcolor=SURFACE_COLOR,
            expand=True,
            value=f"{initial_km:.2f}"
        )
        nonlocal km_input_ref
        km_input_ref = km_input

        def on_km_input_change(e):
            nonlocal km_edited, last_km
            km_edited = True
            parsed = to_float_safe(km_input.value, default=None)
            if parsed is not None:
                last_km = parsed
            persist_progress(force=True)

        km_input.on_change = on_km_input_change

        def reset_km_to_gps(field):
            nonlocal km_edited, km_macro_edited, current_breadcrumbs_distance
            if field is km_input:
                km_edited = False
            else:
                km_macro_edited = False
            if last_gps_lat and last_gps_lon:
                gap = compute_gap_from_last_event(last_gps_lat, last_gps_lon)
                if gap is not None and gap >= MIN_DIST_KM:
                    current_breadcrumbs_distance = max(current_breadcrumbs_distance, gap)
            update_breadcrumb_labels()
            update_km_fields()
            persist_progress(force=True)
            page.update()
            show_toast(f"KM recalculado pelo GPS (+{current_breadcrumbs_distance:.2f} km)")

        def _adjust_km_field(field, delta):
            nonlocal last_km, km_edited, km_macro_edited
            current = to_float_safe(field.value, default=(last_km + current_breadcrumbs_distance))
            new_val = round(current + delta, 2)
            field.value = f"{new_val:.2f}"
            if field is km_input:
                km_edited = True
                if km_macro_input and not km_macro_edited:
                    km_macro_input.value = f"{new_val:.2f}"
            else:
                km_macro_edited = True
                if km_input and not km_edited:
                    km_input.value = f"{new_val:.2f}"
            last_km = new_val
            persist_progress(force=True)
            page.update()

        km_stepper = ft.Row(
            [
                ft.IconButton(icon=ft.icons.REMOVE_CIRCLE_OUTLINE, icon_color=PRIMARY_COLOR, icon_size=28, tooltip="Diminuir 1 KM", on_click=lambda e: _adjust_km_field(km_input, -1)),
                km_input,
                ft.IconButton(icon=ft.icons.ADD_CIRCLE_OUTLINE, icon_color=PRIMARY_COLOR, icon_size=28, tooltip="Aumentar 1 KM", on_click=lambda e: _adjust_km_field(km_input, 1)),
                ft.IconButton(icon=ft.icons.GPS_FIXED_ROUNDED, icon_color=ACCENT_COLOR, icon_size=24, tooltip="Recalcular KM pelo GPS (automático)", on_click=lambda e: reset_km_to_gps(km_input)),
            ],
            spacing=2,
            vertical_alignment=ft.CrossAxisAlignment.CENTER
        )

        nonlocal lat_input_ctrl, lon_input_ctrl
        lat_input = ft.TextField(
            label="Latitude",
            value=f"{last_gps_lat:.6f}",
            border_color=TEXT_MUTED,
            color=TEXT_COLOR,
            bgcolor=SURFACE_COLOR,
            expand=True,
            read_only=True
        )
        lon_input = ft.TextField(
            label="Longitude",
            value=f"{last_gps_lon:.6f}",
            border_color=TEXT_MUTED,
            color=TEXT_COLOR,
            bgcolor=SURFACE_COLOR,
            expand=True,
            read_only=True
        )
        lat_input_ctrl = lat_input
        lon_input_ctrl = lon_input

        visible_macros = [cfg["nome"] for cfg in macro_configs if cfg.get("visivel_motorista", True)]
        if not visible_macros:
            visible_macros = ["Abastecimento", "Manutenções", "Outros"]

        macro_dropdown = ft.Dropdown(
            label="Tipo de Registro Especial",
            options=[ft.dropdown.Option(x) for x in visible_macros],
            bgcolor=SURFACE_COLOR,
            color=TEXT_COLOR,
            border_color=PRIMARY_COLOR,
            value=visible_macros[0] if visible_macros else None
        )

        km_macro_input = ft.TextField(
            label="KM Atual",
            keyboard_type=ft.KeyboardType.NUMBER,
            border_color=PRIMARY_COLOR,
            color=TEXT_COLOR,
            bgcolor=SURFACE_COLOR,
            expand=True,
            value=f"{initial_km:.2f}"
        )
        nonlocal km_macro_input_ref
        km_macro_input_ref = km_macro_input

        def on_km_macro_input_change(e):
            nonlocal km_macro_edited, last_km
            km_macro_edited = True
            parsed = to_float_safe(km_macro_input.value, default=None)
            if parsed is not None:
                last_km = parsed
            persist_progress(force=True)

        km_macro_input.on_change = on_km_macro_input_change

        km_macro_stepper = ft.Row(
            [
                ft.IconButton(icon=ft.icons.REMOVE_CIRCLE_OUTLINE, icon_color=ACCENT_COLOR, icon_size=28, tooltip="Diminuir 1 KM", on_click=lambda e: _adjust_km_field(km_macro_input, -1)),
                km_macro_input,
                ft.IconButton(icon=ft.icons.ADD_CIRCLE_OUTLINE, icon_color=ACCENT_COLOR, icon_size=28, tooltip="Aumentar 1 KM", on_click=lambda e: _adjust_km_field(km_macro_input, 1)),
                ft.IconButton(icon=ft.icons.GPS_FIXED_ROUNDED, icon_color=PRIMARY_COLOR, icon_size=24, tooltip="Recalcular KM pelo GPS (automático)", on_click=lambda e: reset_km_to_gps(km_macro_input)),
            ],
            spacing=2,
            vertical_alignment=ft.CrossAxisAlignment.CENTER
        )

        litros_input = ft.TextField(
            label="Litros",
            keyboard_type=ft.KeyboardType.NUMBER,
            border_color=PRIMARY_COLOR,
            color=TEXT_COLOR,
            bgcolor=SURFACE_COLOR
        )

        valor_litro_input = ft.TextField(
            label="Valor por Litro (R$)",
            keyboard_type=ft.KeyboardType.NUMBER,
            border_color=PRIMARY_COLOR,
            color=TEXT_COLOR,
            bgcolor=SURFACE_COLOR
        )

        valor_total_input = ft.TextField(
            label="Valor Total (R$) - Outros",
            keyboard_type=ft.KeyboardType.NUMBER,
            border_color=PRIMARY_COLOR,
            color=TEXT_COLOR,
            bgcolor=SURFACE_COLOR,
            visible=False
        )

        desc_input = ft.TextField(
            label="Descrição",
            border_color=PRIMARY_COLOR,
            color=TEXT_COLOR,
            bgcolor=SURFACE_COLOR
        )

        def on_macro_change(e):
            is_abastecimento = macro_dropdown.value == "Abastecimento"
            is_outro = macro_dropdown.value in ["Outros", "Aluguel da garagem"]
            litros_input.visible = is_abastecimento
            valor_litro_input.visible = is_abastecimento
            valor_total_input.visible = is_outro or macro_dropdown.value == "Manutenções"
            page.update()

        macro_dropdown.on_change = on_macro_change

        breadcrumbs_label = ft.Text(
            f"KMs percorridos desde o último registro: {current_breadcrumbs_distance:.2f} km",
            size=12,
            color=TEXT_MUTED,
            weight=ft.FontWeight.W_500
        )
        breadcrumbs_macro_label = ft.Text(
            f"KMs percorridos desde o último registro: {current_breadcrumbs_distance:.2f} km",
            size=12,
            color=TEXT_MUTED,
            weight=ft.FontWeight.W_500
        )
        nonlocal breadcrumbs_label_ref, breadcrumbs_macro_label_ref, simular_movimento_switch_ref
        breadcrumbs_label_ref = breadcrumbs_label
        breadcrumbs_macro_label_ref = breadcrumbs_macro_label

        def on_movimento_switch(e):
            nonlocal simular_movimento
            simular_movimento = e.control.value

        simular_switch = ft.Switch(
            label="Simular Movimento GPS",
            value=simular_movimento,
            on_change=on_movimento_switch,
            active_color=PRIMARY_COLOR
        )
        simular_movimento_switch_ref = simular_switch

        # Card de ferramentas Sandbox (visível apenas para empresas marcadas como Sandbox)
        sandbox_card = ft.Container(
            content=ft.Column(
                [
                    ft.Row(
                        [
                            ft.Icon(ft.icons.SCIENCE, color=WARNING_COLOR, size=18),
                            ft.Text("Ferramentas de Teste (Sandbox)", color=WARNING_COLOR, size=13, weight=ft.FontWeight.BOLD),
                        ],
                        spacing=6
                    ),
                    ft.Row(
                        [
                            force_offline_switch,
                            simular_switch,
                        ],
                        wrap=True,
                        spacing=15
                    )
                ],
                spacing=8
            ),
            padding=ft.padding.symmetric(horizontal=14, vertical=10),
            bgcolor=SURFACE_LIGHT,
            border=ft.border.all(1, WARNING_COLOR),
            border_radius=10,
            visible=False
        )

        def update_sandbox_visibility():
            try:
                is_sandbox = db.is_empresa_sandbox(current_empresa_id)
            except Exception:
                is_sandbox = False
            try:
                sandbox_card.visible = is_sandbox
            except Exception:
                pass
            page.update()

        nonlocal update_sandbox_visibility_ref
        update_sandbox_visibility_ref = update_sandbox_visibility

        # Ajusta visibilidade inicial conforme sandbox
        update_sandbox_visibility()

        # Label do último evento (atualizado após a sincronização)
        last_event_label = ft.Text(f"Último evento: {last_daily_event or 'Nenhum'}", color=ACCENT_COLOR, size=14, weight=ft.FontWeight.W_500)
        nonlocal last_event_label_ref
        last_event_label_ref = last_event_label

        # Aba 1: Registro
        tab_registro = ft.Column(
            [
                sync_banner,
                sandbox_card,
                ft.Container(
                    content=ft.Column(
                        [
                            ft.Text("Jornada Diária", size=20, weight=ft.FontWeight.BOLD, color=TEXT_COLOR),
                            last_event_label,
                            event_dropdown,
                            km_stepper,
                            breadcrumbs_label,
                            ft.Row([lat_input, lon_input], spacing=10),
                            ft.ElevatedButton(
                                "Registrar Evento da Rota",
                                icon=ft.icons.PLAY_ARROW_ROUNDED,
                                bgcolor=PRIMARY_COLOR,
                                color=TEXT_COLOR,
                                on_click=save_daily,
                                style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=8)),
                                width=350
                            )
                        ],
                        spacing=15
                    ),
                    padding=20,
                    bgcolor=SURFACE_COLOR,
                    border_radius=12,
                ),
                ft.Divider(height=20, color=ft.colors.TRANSPARENT),
                ft.Container(
                    content=ft.Column(
                        [
                            ft.Text("Despesas e Eventos Extras", size=20, weight=ft.FontWeight.BOLD, color=TEXT_COLOR),
                            macro_dropdown,
                            km_macro_stepper,
                            breadcrumbs_macro_label,
                            litros_input,
                            valor_litro_input,
                            valor_total_input,
                            desc_input,
                            ft.ElevatedButton(
                                "Registrar Despesa",
                                icon=ft.icons.MONETIZATION_ON_OUTLINED,
                                bgcolor=ACCENT_COLOR,
                                color=TEXT_COLOR,
                                on_click=save_macro,
                                style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=8)),
                                width=350
                            )
                        ],
                        spacing=15
                    ),
                    padding=20,
                    bgcolor=SURFACE_COLOR,
                    border_radius=12,
                )
            ],
            scroll=ft.ScrollMode.AUTO,
            expand=True
        )

        # Aba 2: Histórico/Rota do Dia
        events_timeline = ft.Column(spacing=15, scroll=ft.ScrollMode.AUTO)

        def load_timeline_events(days=1):
            nonlocal load_timeline_events_ref
            load_timeline_events_ref = load_timeline_events
            events_timeline.controls.clear()
            # Janela baseada no fuso local (America/Sao_Paulo), convertida para UTC
            start_time = _local_day_start_utc(0 if days == 1 else days)
            
            try:
                evs = db.get_daily_events(start_date=start_time, empresa_id=current_empresa_id, usuario_id=current_driver_id)
                if not evs:
                    events_timeline.controls.append(
                        ft.Container(
                            content=ft.Text("Nenhum evento registrado nesse período.", color=TEXT_MUTED, text_align=ft.TextAlign.CENTER),
                            alignment=ft.alignment.center,
                            padding=40
                        )
                    )
                else:
                    def confirm_delete_event(ev_data):
                        dlg = None
                        def do_delete(e):
                            nonlocal pending_sync_count
                            dlg.open = False
                            page.update()
                            try:
                                db.delete_daily_event(ev_data["id"])
                                show_toast(f"Registro '{ev_data['nome_evento']}' apagado!")
                                load_timeline_events(current_timeline_days)
                                refresh_last_km()
                                refresh_last_event()
                                pending_sync_count = db.get_unsynced_count()
                                if sync_banner_ref:
                                    sync_banner_ref.visible = (pending_sync_count > 0)
                                    sync_banner_ref.content.controls[1].value = f"{pending_sync_count} registros pendentes offline"
                                page.update()
                            except Exception as ex:
                                show_toast(f"Erro ao apagar registro: {ex}", True)

                        dlg = ft.AlertDialog(
                            title=ft.Text("Confirmar Exclusão"),
                            content=ft.Text(f"Deseja realmente apagar o registro '{ev_data['nome_evento']}' (KM: {ev_data.get('km_atual', '-')})?"),
                            actions=[
                                ft.TextButton("Cancelar", on_click=lambda e: setattr(dlg, "open", False) or page.update()),
                                ft.ElevatedButton("Apagar", bgcolor=ft.colors.RED_600, color=TEXT_COLOR, on_click=do_delete)
                            ],
                            actions_alignment=ft.MainAxisAlignment.END
                        )
                        page.overlay.append(dlg)
                        dlg.open = True
                        page.update()

                    for ev in evs:
                        dt = _format_local(ev["data_hora"])
                        # Indica graficamente se está sincronizado
                        sync_icon = ft.Icon(ft.icons.CLOUD_DONE_ROUNDED, color=ACCENT_COLOR, size=16, tooltip="Sincronizado na Nuvem") if ev.get("sincronizado", 1) == 1 else ft.Icon(ft.icons.CLOUD_OFF_ROUNDED, color=WARNING_COLOR, size=16, tooltip="Pendente de Sincronização")
                        
                        delete_btn = ft.IconButton(
                            icon=ft.icons.DELETE_OUTLINE_ROUNDED,
                            icon_color=ft.colors.RED_400,
                            icon_size=20,
                            tooltip="Apagar registro",
                            on_click=(lambda ev_target: lambda e: confirm_delete_event(ev_target))(ev)
                        )

                        events_timeline.controls.append(
                            ft.Container(
                                content=ft.ListTile(
                                    leading=ft.Icon(ft.icons.LOCATION_ON, color=PRIMARY_COLOR),
                                    title=ft.Row([ft.Text(ev["nome_evento"], color=TEXT_COLOR, weight=ft.FontWeight.BOLD, expand=True), sync_icon]),
                                    subtitle=ft.Text(f"KM: {ev['km_atual']} | Lat: {ev['latitude']} | Lon: {ev['longitude']}", color=TEXT_MUTED),
                                    trailing=ft.Row(
                                        [
                                            ft.Text(dt, color=ACCENT_COLOR, size=12),
                                            delete_btn
                                        ],
                                        alignment=ft.MainAxisAlignment.END,
                                        tight=True,
                                        spacing=0
                                    )
                                ),
                                bgcolor=SURFACE_COLOR,
                                border_radius=8,
                                padding=5
                            )
                        )
            except Exception as ex:
                events_timeline.controls.append(ft.Text(f"Erro: {ex}", color=ft.colors.RED_400))
            page.update()

        # Filtro da timeline com destaque do período ativo
        timeline_filter_buttons = {}

        def _timeline_btn_style(active):
            return ft.ButtonStyle(color=PRIMARY_COLOR if active else TEXT_MUTED)

        def set_timeline_filter(days):
            nonlocal current_timeline_days
            current_timeline_days = days
            for d, btn in timeline_filter_buttons.items():
                btn.style = _timeline_btn_style(d == days)
            load_timeline_events(days)

        btn_hoje = ft.TextButton("Hoje", on_click=lambda e: set_timeline_filter(1))
        btn_semana = ft.TextButton("Esta Semana", on_click=lambda e: set_timeline_filter(7))
        btn_30 = ft.TextButton("Últimos 30 Dias", on_click=lambda e: set_timeline_filter(30))
        timeline_filter_buttons[1] = btn_hoje
        timeline_filter_buttons[7] = btn_semana
        timeline_filter_buttons[30] = btn_30

        # Inicia já com "Hoje" selecionado (sem precisar clicar)
        set_timeline_filter(1)

        tab_historico = ft.Column(
            [
                ft.Text("Minha Rota", size=22, weight=ft.FontWeight.BOLD, color=TEXT_COLOR),
                ft.Row(
                    [btn_hoje, btn_semana, btn_30],
                    alignment=ft.MainAxisAlignment.SPACE_AROUND
                ),
                ft.Divider(height=10, color=PRIMARY_COLOR),
                ft.Container(
                    content=events_timeline,
                    expand=True
                )
            ],
            expand=True
        )

        def open_gps_settings_dialog(e):
            presets_dropdown = ft.Dropdown(
                label="Localização Sugerida",
                options=[
                    ft.dropdown.Option("sbc", "São Bernardo (Sen. Vergueiro, 2099)"),
                    ft.dropdown.Option("sp", "São Paulo (Centro - Praça da Sé)"),
                    ft.dropdown.Option("custom", "Localização Personalizada")
                ],
                value="sbc" if abs(last_gps_lat - (-23.6835)) < 0.01 else ("sp" if abs(last_gps_lat - (-23.5505)) < 0.01 else "custom"),
                bgcolor=SURFACE_COLOR,
                color=TEXT_COLOR,
                border_color=PRIMARY_COLOR
            )
            
            custom_lat = ft.TextField(
                label="Latitude",
                value=f"{last_gps_lat:.6f}",
                border_color=PRIMARY_COLOR,
                bgcolor=SURFACE_COLOR,
                visible=presets_dropdown.value == "custom"
            )
            
            custom_lon = ft.TextField(
                label="Longitude",
                value=f"{last_gps_lon:.6f}",
                border_color=PRIMARY_COLOR,
                bgcolor=SURFACE_COLOR,
                visible=presets_dropdown.value == "custom"
            )

            def on_preset_change(e):
                is_custom = presets_dropdown.value == "custom"
                custom_lat.visible = is_custom
                custom_lon.visible = is_custom
                if presets_dropdown.value == "sbc":
                    custom_lat.value = "-23.683500"
                    custom_lon.value = "-46.555300"
                elif presets_dropdown.value == "sp":
                    custom_lat.value = "-23.550520"
                    custom_lon.value = "-46.633308"
                dialog.update()

            presets_dropdown.on_change = on_preset_change

            def save_gps_config(e):
                nonlocal last_gps_lat, last_gps_lon, current_breadcrumbs_distance
                try:
                    lat_val = float(custom_lat.value)
                    lon_val = float(custom_lon.value)
                    last_gps_lat = lat_val
                    last_gps_lon = lon_val
                    current_breadcrumbs_distance = 0.0 # Reseta distância ao pular para outro local
                    persist_progress(force=True)

                    if lat_input_ctrl and lon_input_ctrl:
                        lat_input_ctrl.value = f"{last_gps_lat:.6f}"
                        lon_input_ctrl.value = f"{last_gps_lon:.6f}"
                        page.update()
                        
                    show_toast("GPS Inicial atualizado com sucesso!")
                    dialog.open = False
                    page.update()
                except ValueError:
                    show_toast("Valores de latitude e longitude inválidos!", True)

            dialog = ft.AlertDialog(
                title=ft.Text("Ajustar Localização"),
                content=ft.Column(
                    [
                        presets_dropdown,
                        custom_lat,
                        custom_lon
                    ],
                    spacing=10,
                    width=350,
                    height=200,
                    scroll=ft.ScrollMode.AUTO
                ),
                actions=[
                    ft.TextButton("Cancelar", on_click=lambda e: setattr(dialog, "open", False) or page.update()),
                    ft.TextButton("Salvar", on_click=save_gps_config)
                ],
                actions_alignment=ft.MainAxisAlignment.END
            )
            
            page.overlay.append(dialog)
            dialog.open = True
            page.update()

        async def handle_logout(e):
            persist_progress(force=True)
            await page.client_storage.remove_async("session_driver_id")
            await page.client_storage.remove_async("session_empresa_id")
            await page.client_storage.remove_async("session_driver_nome")
            nonlocal current_driver, current_driver_id, current_empresa_id, last_daily_event, daily_events_list, last_km, current_breadcrumbs_distance
            current_driver = None
            current_driver_id = None
            current_empresa_id = None
            last_daily_event = None
            daily_events_list = []
            last_km = 0.0
            current_breadcrumbs_distance = 0.0
            show_login()

        # Update tabs config
        tabs = ft.Tabs(
            selected_index=0,
            animation_duration=300,
            tabs=[
                ft.Tab(text="Registros", icon=ft.icons.EDIT_NOTE, content=tab_registro),
                ft.Tab(text="Minha Rota", icon=ft.icons.ROUTE, content=tab_historico),
            ],
            expand=True,
            label_color=PRIMARY_COLOR,
            unselected_label_color=TEXT_MUTED,
            indicator_color=PRIMARY_COLOR
        )

        page.views.append(
            ft.View(
                "/dashboard",
                [
                    ft.AppBar(
                        title=ft.Column(
                            [
                                ft.Text("SmartFrota", weight=ft.FontWeight.BOLD, color=TEXT_COLOR, size=18),
                                ft.Text(f"{current_driver} | Van: {current_vehicle['modelo'] if current_vehicle else 'Sem van'} ({current_vehicle['placa'] if current_vehicle else '--'})", size=11, color=TEXT_MUTED)
                            ],
                            spacing=2
                        ),
                        center_title=False,
                        bgcolor=SURFACE_COLOR,
                        actions=[
                            status_badge,
                            ft.IconButton(ft.icons.SYNC_ROUNDED, icon_color=TEXT_COLOR, on_click=trigger_sync, tooltip="Sincronizar Agora"),
                            ft.IconButton(ft.icons.GPS_FIXED, icon_color=PRIMARY_COLOR, on_click=open_gps_settings_dialog, tooltip="Ajustar GPS"),
                            ft.IconButton(ft.icons.LOGOUT, icon_color=TEXT_MUTED, on_click=handle_logout)
                        ]
                    ),
                    ft.Container(
                        content=tabs,
                        padding=15,
                        expand=True
                    )
                ],
                bgcolor=BG_COLOR
            )
        )
        page.update()

    # Recarrega o último KM registrado e atualiza os campos de KM na tela
    def refresh_last_km():
        nonlocal last_km, km_edited, km_macro_edited
        if not current_driver_id:
            return
        try:
            db_km = db.get_last_registered_km(empresa_id=current_empresa_id, usuario_id=current_driver_id)
            db_km = float(db_km) if db_km is not None else 0.0
        except Exception as e:
            print(f"Erro ao recarregar último KM: {e}")
            return
        try:
            if not km_edited and not km_macro_edited:
                last_km = db_km
            suggested = (last_km if (km_edited or km_macro_edited) else db_km) + current_breadcrumbs_distance
            if km_input_ref is not None and not km_edited:
                km_input_ref.value = f"{suggested:.2f}"
            if km_macro_input_ref is not None and not km_macro_edited:
                km_macro_input_ref.value = f"{suggested:.2f}"
            page.update()
        except Exception:
            pass

    # Recarrega os eventos de hoje e atualiza o "último evento" e o próximo evento sequencial
    def refresh_last_event():
        nonlocal last_daily_event, daily_events_list
        if not current_driver_id:
            return
        try:
            today_start = _local_day_start_utc(0)
            evs = db.get_daily_events(start_date=today_start, empresa_id=current_empresa_id, usuario_id=current_driver_id)
            daily_events_list = evs
            if evs:
                last_daily_event = evs[-1]["nome_evento"]
            else:
                all_evs = db.get_daily_events(empresa_id=current_empresa_id, usuario_id=current_driver_id)
                last_daily_event = all_evs[-1]["nome_evento"] if all_evs else None
        except Exception as e:
            print(f"Erro ao recarregar último evento: {e}")
            return
        try:
            if last_event_label_ref is not None:
                last_event_label_ref.value = f"Último evento: {last_daily_event or 'Nenhum'}"
            if event_dropdown_ref is not None:
                if daily_configs:
                    event_dropdown_ref.options = [ft.dropdown.Option(cfg["nome"]) for cfg in daily_configs]
                else:
                    event_dropdown_ref.options = [ft.dropdown.Option(x) for x in DIARIOS_EVENTOS]
                event_dropdown_ref.value = get_next_sequential_event()
            page.update()
        except Exception:
            pass

    # Loop de sincronização em segundo plano (Push frequente de pendências + Pull espaçado)
    async def sync_worker_loop():
        nonlocal is_online, pending_sync_count
        last_cache_pull = time.monotonic()
        while True:
            try:
                if current_driver_id:
                    online_now = await asyncio.to_thread(db.verificar_conexao) if hasattr(asyncio, "to_thread") else db.verificar_conexao()
                    
                    # Se mudou o status de conexão
                    if online_now != is_online:
                        is_online = online_now
                        if status_badge_ref:
                            status_badge_ref.content.controls[0].bgcolor = ACCENT_COLOR if is_online else WARNING_COLOR
                            status_badge_ref.content.controls[1].value = "Online" if is_online else "Offline"
                            page.update()
                    
                    if is_online:
                        # 1. PUSH: envia registros pendentes locais se houver
                        unsynced = db.get_unsynced_count()
                        if unsynced > 0:
                            sincronizados, _ = await asyncio.to_thread(db.sincronizar_dados_pendentes) if hasattr(asyncio, "to_thread") else db.sincronizar_dados_pendentes()
                            if sincronizados > 0:
                                refresh_last_km()
                                refresh_last_event()
                                if load_timeline_events_ref:
                                    load_timeline_events_ref(current_timeline_days)

                        # 2. PULL: atualiza cadastros/configurações da nuvem a cada 5 minutos (300 segundos)
                        now = time.monotonic()
                        if (now - last_cache_pull) >= 300:
                            last_cache_pull = now
                            await asyncio.to_thread(db.atualizar_cache_local, current_driver_id) if hasattr(asyncio, "to_thread") else db.atualizar_cache_local(current_driver_id)

                            if update_sandbox_visibility_ref:
                                update_sandbox_visibility_ref()

                            refresh_last_km()
                            refresh_last_event()

                            if load_timeline_events_ref:
                                load_timeline_events_ref(current_timeline_days)
                    
                    # Atualiza contador de registros pendentes
                    pending_sync_count = db.get_unsynced_count()
                    if sync_banner_ref:
                        sync_banner_ref.visible = (pending_sync_count > 0)
                        sync_banner_ref.content.controls[1].value = f"{pending_sync_count} registros pendentes offline"
                        page.update()
                        
            except Exception as e:
                print(f"Erro no loop de sincronização: {e}")

            await asyncio.sleep(15) # Roda a cada 15 segundos

    # Leitor de GPS real do dispositivo (navegador/PWA)
    async def gps_reader():
        nonlocal gap_seed_done, first_fix_done, current_breadcrumbs_distance, last_gps_lat, last_gps_lon
        _install_gps_watch()
        while True:
            await asyncio.sleep(4)
            # Em modo sandbox com movimento simulado, o simulador é a fonte de
            # posição (evita acumular a mesma distância duas vezes).
            if simular_movimento:
                continue
            new_lat = GPS_BUFFER.get("lat")
            new_lon = GPS_BUFFER.get("lon")
            if new_lat is None or new_lon is None:
                continue
            if abs(new_lat) > 90 or abs(new_lon) > 180:
                continue

            # Ignora posições imprecisas (GPS frio/coarse)
            acc = GPS_BUFFER.get("accuracy")
            if acc is not None and acc > ACCURACY_LIMIT_M:
                continue

            is_wake = GPS_BUFFER.pop("wake", False)
            lat_f = float(new_lat)
            lon_f = float(new_lon)

            # 1. Distância física em relação ao último evento registrado (origem da perna da viagem)
            gap_from_event = compute_gap_from_last_event(lat_f, lon_f)

            # 2. Primeira leitura de GPS da sessão:
            if not first_fix_done:
                first_fix_done = True
                if gap_from_event is not None and gap_from_event >= MIN_DIST_KM:
                    current_breadcrumbs_distance = max(current_breadcrumbs_distance, gap_from_event)
                last_gps_lat = lat_f
                last_gps_lon = lon_f
                update_gps_fields()
                update_breadcrumb_labels()
                update_km_fields()
                persist_progress(force=True)
                page.update()
                continue

            # 3. Tratamento de retorno de segundo plano (ex.: motorista navegando no Waze)
            # ou salto de localização maior que o pão acumulado:
            # Se o veículo percorreu distância física desde o último evento registrado,
            # a distância percorrida NUNCA pode ser menor que o deslocamento em linha reta.
            if gap_from_event is not None and gap_from_event >= MIN_DIST_KM:
                if current_breadcrumbs_distance < gap_from_event or is_wake:
                    current_breadcrumbs_distance = max(current_breadcrumbs_distance, gap_from_event)
                    last_gps_lat = lat_f
                    last_gps_lon = lon_f
                    update_gps_fields()
                    update_breadcrumb_labels()
                    update_km_fields()
                    persist_progress()
                    page.update()
                    continue

            # 4. Processamento contínuo pão-a-pão (app ativo na tela ou keep-alive em segundo plano)
            if lat_f != last_gps_lat or lon_f != last_gps_lon:
                accumulate_gps_movement(lat_f, lon_f, 4)
                update_gps_fields()
                update_breadcrumb_labels()
                update_km_fields()
                page.update()

    # GPS nativo (Android/iOS) via flet-geolocator, quando disponível.
    # Preenche o GPS_BUFFER que o gps_reader() já consome a cada 10s.
    if GEOLOCATOR_AVAILABLE:
        try:
            geo = Geolocator()

            def on_geo_position_change(e):
                GPS_BUFFER["lat"] = float(e.latitude)
                GPS_BUFFER["lon"] = float(e.longitude)
                GPS_BUFFER["error"] = None

            geo.on_position_change = on_geo_position_change
            page.overlay.append(geo)
            print("GPS: Geolocator nativo instalado.")

            async def geolocator_loop():
                # Pede permissão de localização e mantém o GPS_BUFFER atualizado
                # via leituras periódicas (fallback confiável ao stream de eventos).
                await asyncio.sleep(2.0)
                try:
                    perm = await geo.request_permission_async()
                    print(f"GPS: status da permissão = {perm}")
                except Exception as ex:
                    print(f"GPS: erro ao pedir permissão: {ex}")
                while True:
                    try:
                        pos = await geo.get_current_position_async(wait_timeout=10)
                        if (
                            pos
                            and pos.latitude is not None
                            and pos.longitude is not None
                        ):
                            GPS_BUFFER["lat"] = float(pos.latitude)
                            GPS_BUFFER["lon"] = float(pos.longitude)
                            if getattr(pos, "accuracy", None) is not None:
                                GPS_BUFFER["accuracy"] = float(pos.accuracy)
                            GPS_BUFFER["error"] = None
                    except Exception as ex:
                        print(f"GPS: leitura falhou: {ex}")
                    await asyncio.sleep(10)

            asyncio.create_task(geolocator_loop())
        except Exception as ex:
            print(f"GPS: Geolocator nativo indisponível: {ex}")

    # Iniciar leitura de GPS real do dispositivo
    asyncio.create_task(gps_reader())
    # Iniciar simulação de GPS Breadcrumbs
    asyncio.create_task(gps_simulator())
    # Iniciar sincronização automática em segundo plano
    asyncio.create_task(sync_worker_loop())

    # Mostra a tela de carregamento de início
    show_loading_screen("Verificando sessão...")

    # Auto-login check (persitência de sessão)
    if await page.client_storage.contains_key_async("session_driver_id"):
        current_driver_id = await page.client_storage.get_async("session_driver_id")
        current_empresa_id = await page.client_storage.get_async("session_empresa_id")
        current_driver = await page.client_storage.get_async("session_driver_nome")
        
        show_loading_screen(f"Carregando dados de {current_driver}...")
        
        # Sincroniza dados atualizados do motorista se estiver online
        try:
            is_on = await asyncio.to_thread(db.verificar_conexao) if hasattr(asyncio, "to_thread") else db.verificar_conexao()
            if is_on:
                await asyncio.to_thread(db.atualizar_cache_local, current_driver_id) if hasattr(asyncio, "to_thread") else db.atualizar_cache_local(current_driver_id)
        except Exception as ex:
            print(f"Erro ao sincronizar na inicialização: {ex}")
            
        login_success()
    else:
        current_driver = None
        current_driver_id = None
        current_empresa_id = None
        show_login()

ft.app(target=main)
