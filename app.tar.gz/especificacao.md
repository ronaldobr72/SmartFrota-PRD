# SmartFrota - Especificação Técnica e Funcional

Este documento descreve a especificação do sistema **SmartFrota**, composto por um aplicativo móvel (motorista) e um aplicativo desktop (backoffice) desenvolvidos em **Flet** (Python) e integrados ao banco de dados **Supabase** (compartilhando a infraestrutura existente do SmartDarf).

---

## 1. Arquitetura do Sistema

```mermaid
graph TD
    A[SmartFrota Mobile - Motorista] -->|Supabase Client / API| C[(Supabase DB - SmartDarf)]
    B[SmartFrota Desktop - Backoffice] -->|Supabase Client / API| C[(Supabase DB - SmartDarf)]
```

- **Linguagem / Framework**: Python + Flet (permite compilar tanto para Desktop quanto para Android/iOS usando o mesmo ecossistema).
- **Banco de Dados**: Supabase (PostgreSQL). As tabelas serão criadas no mesmo banco de dados do projeto `SmartDarf` (schema público ou customizado, mantendo isolamento por nomenclatura, ex: prefixo `sf_`).
- **Autenticação**: Usuário padrão no Supabase (configurado inicialmente ou login simples).

---

## 2. Modelo de Dados (Supabase - Postgres)

Para evitar conflitos com as tabelas do `SmartDarf`, todas as tabelas do SmartFrota usarão o prefixo `sf_`.

### 2.1. sf_configuracoes_eventos (Configuração de Eventos Macros)
Controla quais eventos macros estão disponíveis para o motorista no aplicativo móvel.
- `id`: uuid (Primary Key)
- `nome`: text (ex: 'Abastecimento', 'Manutenção', 'Aluguel da garagem', 'Outros')
- `tipo`: text ('macro' ou 'diario')
- `visivel_motorista`: boolean (default: true)
- `created_at`: timestamp

### 2.2. sf_eventos_macros (Registro de Eventos Financeiros/Administrativos)
Registros de eventos de custos maiores.
- `id`: uuid (Primary Key)
- `evento_config_id`: uuid (Foreign Key para `sf_configuracoes_eventos`)
- `data_hora`: timestamp
- `km_atual`: numeric (opcional)
- `litros`: numeric (opcional - específico para abastecimento)
- `valor_por_litro`: numeric (opcional - específico para abastecimento)
- `descricao`: text (opcional)
- `valor_total`: numeric (calculado como `litros * valor_por_litro` ou inserido diretamente para outros eventos)
- `registrado_por`: text (identificação do usuário/função)

### 2.3. sf_eventos_diarios (Registro da Jornada Diária da Van)
Registros sequenciais de movimentação e geolocalização.
- `id`: uuid (Primary Key)
- `nome_evento`: text (ex: 'Retirada na garagem', 'Chegada ao primeiro aluno', etc.)
- `data_hora`: timestamp (default: now())
- `km_atual`: numeric
- `latitude`: numeric
- `longitude`: numeric
- `seq_ordenacao`: integer (para garantir a ordem exata dos eventos no dia)

---

## 3. Funcionalidades do Aplicativo Móvel (Flet)

- **Login Simples**: Credenciais padrão definidas previamente.
- **Tela de Registro**:
  - Exibe botões rápidos para registrar **Eventos Diários** em ordem (cadeia).
  - Impede registros duplicados inválidos (ex: impede "Retirada na garagem" duas vezes seguidas no mesmo dia).
  - Exibe e permite o registro de **Eventos Macros** que estejam marcados como `visivel_motorista = true` (ex: Abastecimento).
- **Tela de Histórico / Rota**:
  - Visualização simples das rotas e eventos realizados no dia, semana ou período filtrado.

---

## 4. Funcionalidades do Backoffice Desktop (Flet)

- **Gestão de Eventos**:
  - Cadastro de novos tipos de eventos e definição de visibilidade para o motorista.
  - Registro direto de eventos administrativos (ex: Aluguel de Garagem, Manutenções complexas).
- **Relatórios Financeiros e Operacionais**:
  - Visualização de custos por: **Dia**, **Mês**, **Trechos** e **Período Customizado**.
  - **Cálculo de Custos por Trechos (Exemplo de Deslocamento entre A e B)**:
    - O sistema identificará os eventos de partida e chegada selecionados (ex: entre "Retirada na garagem" e "Chegada ao primeiro aluno").
    - Calculará a diferença de KM entre esses dois pontos.
    - Multiplicará a distância pelo custo médio por KM (calculado a partir dos abastecimentos e manutenções do período).
    - Apresentará o custo total estimado para o trecho.
    


Considerando o projeto atual  temos os seguintes problemas
 - Falta incluir veiculos - então vamos incluir um ou varios veiculos dentro da empresa
 - Apos a inclusão do veiculo vamos também atribuir um veiculo ao motorista que ja esta atribuido a uma empresa, 
 - Um motorista so pode ser incluido dentro da empresa alias a empresa e a entidade principal e motorista, veiculo, são entidades filhas
 - Melhoria no cadastro de eventos diarios 
     - Um evento diario deve também ser atribuido a uma empresa
     - Apos o evento diario ter sido criado para a empresa, poderemos atribuir os eventos ao motorista e o motorista visualizara apenas os enventos atribuidos a ele.

então essa é a estrutura

Empresa 
  - Eventos Macros 
  - Eventos Diarios  
  - Veiculo 
  - Motorista 
      - Veiculo 1 veiculo por motorista
      - Eventos Diarios ( multiplos ) - aqui a ordem dos eventos importam então vamos precisar de um compo sequencia que indicara a ordem em que os eventos aparecem para o motorita
      - Eventos macros  ( multiplos )

Regras 
  - 1 - Empresa so pode visualizar os dados da propria empresa
    2 - O motorista só podera incluir eventos atribuidos a ele.
    3 - O motorista deve ver apenas os eventos criados por ele mesmo.
    4 - Ao lançar um evento os dados do ultimo evento lancado pelo motorista devem ser mostrados na tela sendo com: 
       - O evento deve aparecer conforme a sequencia de eventos cadastrada para o motorista em loop, quando finalizar o ultimo evento volta ao primeiro, se o motorista alterar o evento nao tem problema, mas ao incluir um novo registro mostraremos o proximo da sequencia.
       - KM atual da van, esse valor podera ser dinamico a medica que a van se desloca devemos ir incrementando, porem nao podemos incrementalo a cada segundo vamos incrementar conforme os dados de geolocalização vão sendo atualizado.
       - Latitude e longitudo - ja esta sendo atualizado de maneira dinamica.

    5 - Despesas Extras - Não é necessario nenhuma mudança visual, mas a regra de ouro é o motorista incluir eventos que já esão associados a empresa e só podera visualizar eventos dele mesmo.

Regras de qualidade ( o agente deve testar essas regras até fiquem 100% funcinais)
  - todos os botãos devem funcionar
  - nao pordemos ter compos que sobreponham outros campos
  - O aplicativo sera utilizado via browser com flet.
  - Não podemos ter problemas de atualização, ou seja se uma nova versão foi divulgada o usuario deve ver a ultima versão mesmo que tenhamos que solicitar que atualize a versao que esta sendo utilizada.
  - precisa criar uma maneira para que mesmo sem internet o sistema continue funcionando sem travar e o usuario possa fazer os lancamentos de forma normal
  - a atualização local deve sempre acontecer e o aplicativo nao pode travar.
  - quando a internet volta vamos fazer uma sincronização automatica, ou/e permitir ao usuario que também faça se assim desejar.
  
  
preciso que voce faça essas mudanças testes as funcionalidades e se algo deu errado corriga o erro e continue corrigindo até 10 vezes ou até que tenhamos uma funcionalidade satisfatoria.
o criterio para a satisfação ou termo de qualidade a ser checado são as regras de qualidade.

me avise se vc pode fazer isso e no momento vamos alterar apenas o app do motorista na versão homologacao.
        
super regra de ouro - manter todos os dados do banco de dados ja cadastrados.