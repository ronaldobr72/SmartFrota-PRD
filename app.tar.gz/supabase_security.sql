-- ============================================================
-- SmartFrota — Segurança Supabase (RLS + proteção da senha)
-- Execute NO SQL EDITOR do painel Supabase:
--   Dashboard -> SQL Editor -> New query -> cole e clique em RUN
-- ============================================================

-- 1) Habilitar RLS em todas as tabelas do app
ALTER TABLE public.sf_empresas ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sf_usuarios ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sf_configuracoes_eventos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sf_veiculos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sf_usuario_configuracoes_eventos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sf_eventos_diarios ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sf_eventos_macros ENABLE ROW LEVEL SECURITY;

-- 2) Políticas permissivas para o papel anon (o app usa a chave publishable = anon).
--    Mantém o funcionamento atual do app. (DROP IF EXISTS torna o script reexecutável)
DROP POLICY IF EXISTS "anon_all_sf_empresas" ON public.sf_empresas;
CREATE POLICY "anon_all_sf_empresas" ON public.sf_empresas
  FOR ALL TO anon USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_all_sf_configuracoes_eventos" ON public.sf_configuracoes_eventos;
CREATE POLICY "anon_all_sf_configuracoes_eventos" ON public.sf_configuracoes_eventos
  FOR ALL TO anon USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_all_sf_veiculos" ON public.sf_veiculos;
CREATE POLICY "anon_all_sf_veiculos" ON public.sf_veiculos
  FOR ALL TO anon USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_all_sf_usuario_configuracoes_eventos" ON public.sf_usuario_configuracoes_eventos;
CREATE POLICY "anon_all_sf_usuario_configuracoes_eventos" ON public.sf_usuario_configuracoes_eventos
  FOR ALL TO anon USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_all_sf_eventos_diarios" ON public.sf_eventos_diarios;
CREATE POLICY "anon_all_sf_eventos_diarios" ON public.sf_eventos_diarios
  FOR ALL TO anon USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_all_sf_eventos_macros" ON public.sf_eventos_macros;
CREATE POLICY "anon_all_sf_eventos_macros" ON public.sf_eventos_macros
  FOR ALL TO anon USING (true) WITH CHECK (true);

-- 3) PROTEÇÃO DA SENHA (o ponto crítico):
--    Remove todo o acesso de `anon` à tabela sf_usuarios e concede apenas
--    leitura das colunas NÃO sensíveis. Assim o PostgREST nunca devolve `senha`.
REVOKE ALL ON public.sf_usuarios FROM anon;
GRANT SELECT (id, empresa_id, nome, email, role, veiculo_id) ON public.sf_usuarios TO anon;

--    (A listagem de contas no login continua funcionando, pois usa id/nome/empresa.)

-- 4) Função segura de autenticação: valida a senha NO SERVIDOR e devolve só true/false.
--    O app chama esta função em vez de comparar a senha no cliente.
CREATE OR REPLACE FUNCTION public.autenticar_motorista(p_usuario_id text, p_senha text)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.sf_usuarios
    WHERE id::text = p_usuario_id AND senha = p_senha
  );
$$;

REVOKE ALL ON FUNCTION public.autenticar_motorista(text, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.autenticar_motorista(text, text) TO anon;

-- ============================================================
-- Depois de rodar, a chave pública NÃO consegue mais ler senhas.
-- O app atualizado valida o login via rpc/autenticar_motorista.
-- ============================================================
