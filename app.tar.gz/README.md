# SmartFrota

Repositório de código-fonte do projeto SmartFrota.

Como usar

- Instale dependências: `pip install -r requirements.txt`
- Execute scripts conforme necessário, por exemplo `python main_desktop.py`.

Branches

- `main`: produção
- `fontes`: sincronização de fontes (esta branch)

Contribuição

- Abra pull requests da branch `fontes` para `main`.
