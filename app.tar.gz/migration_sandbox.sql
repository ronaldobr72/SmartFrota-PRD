-- Migração: adicionar a coluna sandbox em sf_empresas
-- Execute este script no SQL Editor do Supabase.

ALTER TABLE public.sf_empresas ADD COLUMN IF NOT EXISTS sandbox BOOLEAN DEFAULT false;

-- Marca a empresa SANDBOX existente como sandbox
UPDATE public.sf_empresas SET sandbox = true WHERE id = '8f6ddc0f-290a-4d2c-a8ea-794c08f4fc8c';
