#!/bin/bash
# =======================================================
#   SmartFrota - Auto Deploy PWA (QA) - macOS
#   Equivalente ao deploy_homolog.bat do Windows
#
#   Uso:
#     ./deploy_homolog.sh          # build + commit + push
#     ./deploy_homolog.sh --force  # força o push (--force)
# =======================================================
set -euo pipefail

# ---------- Configurações (ajuste se necessário) ----------
# Diretório dos fontes (onde este script está)
SOURCE_DIR="$(cd "$(dirname "$0")" && pwd)"

# Diretório do repositório de deploy (QA)
QA_DIR="${QA_DIR:-/Users/ronaldofranciscorosa/SmartFrota-QA}"

# Ambiente virtual com flet 0.23.2 (necessário para o build web)
VENV_BIN="${VENV_BIN:-/Users/ronaldofranciscorosa/smartfrota-build-venv/bin}"
FLET="$VENV_BIN/flet"
PYTHON="$VENV_BIN/python"

# Base URL do GitHub Pages
BASE_URL="/SmartFrota-QA/"

# Flag de force-push
FORCE=""
if [[ "${1:-}" == "--force" ]]; then
    FORCE="--force"
fi
# ----------------------------------------------------------

echo "======================================================="
echo "   SmartFrota - Auto Deploy PWA (QA)"
echo "======================================================="
echo ""

# Verifica dependências
if [[ ! -x "$FLET" ]]; then
    echo "[ERRO] flet não encontrado em $FLET"
    echo "       Crie o venv: python3 -m venv ~/smartfrota-build-venv"
    echo "       e instale:   ~/smartfrota-build-venv/bin/pip install flet==0.23.2 python-dotenv==1.0.1"
    exit 1
fi
if [[ ! -d "$QA_DIR/.git" ]]; then
    echo "[ERRO] Repositório QA não encontrado em $QA_DIR"
    echo "       Clone com: git clone https://github.com/ronaldobr72/SmartFrota-QA.git \"$QA_DIR\""
    exit 1
fi

echo "1. Limpando cache local (evita empacotar o banco local)..."
rm -rf "$SOURCE_DIR/local_cache.db" "$SOURCE_DIR/__pycache__"

echo "2. Compilando o aplicativo Flet para Web (QA)..."
cd "$SOURCE_DIR"
"$FLET" publish main_mobile.py --base-url "$BASE_URL"

echo "3. Aplicando patch de versão do Flet WebAssembly e branding QA (âmbar)..."
"$PYTHON" patch_worker.py --env homolog

echo "3.1 Gerando ícones e imagens SmartFrota (QA - Âmbar)..."
if ! python3 -c "import PIL" 2>/dev/null; then
    echo "[ERRO] Pillow não encontrado. Instale com: pip3 install pillow"
    exit 1
fi
python3 generate_icons.py --env homolog

echo "4. Sincronizando o build para o repositório QA..."
rsync -a --delete --exclude='.git' "$SOURCE_DIR/dist/" "$QA_DIR/"

echo "5. Commitando e enviando..."
cd "$QA_DIR"
if [[ -n "$(git status --porcelain)" ]]; then
    git add -A
    git -c user.name="ronaldobr72" -c user.email="ronaldobr72@users.noreply.github.com" \
        commit -m "Deploy Flet PWA App - QA Build ($(date '+%Y-%m-%d %H:%M:%S'))"
else
    echo "   Nenhuma mudança para commitar."
fi
git push origin main $FORCE

echo ""
echo "======================================================="
echo "   Deploy concluído!"
echo "   https://ronaldobr72.github.io/SmartFrota-QA/"
echo "======================================================="
