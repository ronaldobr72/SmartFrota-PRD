import flet as ft
from datetime import datetime, timedelta, timezone
import database as db
db.DIRECT_SUPABASE = True

# Fuso horário local (America/Sao_Paulo — sem horário de verão desde 2019)
LOCAL_TZ = timezone(timedelta(hours=-3), name="America/Sao_Paulo")

def _format_local(dt_str, fmt="%d/%m/%Y %H:%M"):
    """Converte timestamp ISO (UTC) para horário local de Brasília."""
    try:
        dt = datetime.fromisoformat(dt_str.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(LOCAL_TZ).strftime(fmt)
    except Exception:
        return dt_str or ""

def _parse_local_dt(dt_str):
    """Converte data/hora local (AAAA-MM-DD HH:MM:SS) para datetime UTC."""
    dt = datetime.strptime(dt_str.strip(), "%Y-%m-%d %H:%M:%S")
    return dt.replace(tzinfo=LOCAL_TZ).astimezone(timezone.utc)

# Configurações de design moderno (Aesthetics)
BG_COLOR = "#0B0F19"       # Deep Dark Blue
SURFACE_COLOR = "#111827"  # Slate 900
SURFACE_LIGHT = "#1F2937"  # Slate 800
PRIMARY_COLOR = "#2563EB"  # Blue 600
ACCENT_COLOR = "#059669"   # Emerald 600
WARNING_COLOR = "#F59E0B"  # Amber 500
TEXT_COLOR = "#F9FAFB"     # Slate 50
TEXT_MUTED = "#9CA3AF"     # Slate 400

def main(page: ft.Page):
    page.title = "SmartFrota - Backoffice"
    page.theme_mode = ft.ThemeMode.DARK
    page.bgcolor = BG_COLOR
    page.padding = 20
    page.window.width = 1200
    page.window.height = 850
    page.window.resizable = True

    # Demo Companies/Tenants
    DEMO_COMPANIES = []
    current_empresa_id = ""

    def load_companies():
        nonlocal DEMO_COMPANIES, current_empresa_id
        try:
            real_emp = db.get_empresas()
            if real_emp:
                DEMO_COMPANIES = real_emp
        except Exception as e:
            print(f"Erro ao carregar empresas: {e}")
            DEMO_COMPANIES = [
                {"id": "demo-empresa-1", "nome": "Empresa Demo SmartFrota"},
                {"id": "e890f1ee-6c54-4b01-90e6-d701748f0852", "nome": "Transportes Estrela"},
                {"id": "f890f1ee-6c54-4b01-90e6-d701748f0853", "nome": "Logística Global"},
            ]
        if DEMO_COMPANIES:
            if not current_empresa_id or current_empresa_id not in [c["id"] for c in DEMO_COMPANIES]:
                current_empresa_id = DEMO_COMPANIES[0]["id"]

    load_companies()

    # State variables
    macro_configs = []
    daily_events = []
    macro_events = []
    usuarios = []
    veiculos = []

    # Toast feedback helper
    def show_toast(msg, is_error=False):
        snack = ft.SnackBar(
            content=ft.Text(msg, color=TEXT_COLOR),
            bgcolor=ft.colors.RED_500 if is_error else ACCENT_COLOR
        )
        page.overlay.append(snack)
        snack.open = True
        page.update()

    # Carga de dados inicial
    def load_data():
        nonlocal macro_configs, daily_events, macro_events, usuarios, veiculos
        try:
            macro_configs = db.get_event_configs(empresa_id=current_empresa_id)
            daily_events = db.get_daily_events(empresa_id=current_empresa_id)
            macro_events = db.get_macro_events(empresa_id=current_empresa_id)
            veiculos = db.get_veiculos(current_empresa_id)
            try:
                all_users = db.get_usuarios()
                usuarios = [u for u in all_users if u.get("empresa_id") == current_empresa_id]
            except Exception:
                usuarios = []
        except Exception as e:
            print(f"Erro ao carregar dados: {e}")

    load_data()

    # --- GERENCIAMENTO DE CONFIGURAÇÕES DE EVENTOS (MACROS) ---
    config_list = ft.Column(spacing=10, scroll=ft.ScrollMode.AUTO, expand=True)

    def reload_configs_ui():
        load_data()
        config_list.controls.clear()
        
        for cfg in macro_configs:
            def make_toggle_handler(config_id=cfg["id"]):
                return lambda e: toggle_visibility(config_id, e.control.value)

            config_list.controls.append(
                ft.Container(
                    content=ft.Row(
                        [
                            ft.Icon(ft.icons.SETTINGS_SUGGEST, color=PRIMARY_COLOR),
                            ft.Text(cfg["nome"], color=TEXT_COLOR, size=16, weight=ft.FontWeight.BOLD, expand=True),
                            ft.Text(f"Tipo: {cfg['tipo'].capitalize()}", color=TEXT_MUTED, size=14),
                            ft.VerticalDivider(width=10),
                            ft.Switch(
                                label="Visível p/ Motorista",
                                value=cfg["visivel_motorista"],
                                on_change=make_toggle_handler(),
                                active_color=ACCENT_COLOR
                            )
                        ],
                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN
                    ),
                    bgcolor=SURFACE_LIGHT,
                    padding=10,
                    border_radius=8
                )
            )
        page.update()

    def toggle_visibility(config_id, value):
        try:
            db.update_event_config_visibility(config_id, value)
            show_toast("Configuração de visibilidade atualizada!")
            reload_configs_ui()
        except Exception as ex:
            show_toast(f"Erro ao atualizar visibilidade: {ex}", True)

    def add_new_config(e):
        nome = new_config_name.value
        tipo = new_config_type.value
        visivel = new_config_visible.value

        if not nome:
            show_toast("Nome do evento é obrigatório!", True)
            return

        try:
            db.add_event_config(nome, tipo, visivel, empresa_id=current_empresa_id)
            show_toast(f"Configuração '{nome}' criada com sucesso!")
            new_config_name.value = ""
            reload_configs_ui()
        except Exception as ex:
            show_toast(f"Erro ao criar configuração: {ex}", True)

    new_config_name = ft.TextField(label="Nome do Evento (ex: Limpeza)", border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT)
    new_config_type = ft.Dropdown(
        label="Tipo",
        options=[ft.dropdown.Option("macro"), ft.dropdown.Option("diario")],
        value="macro",
        border_color=PRIMARY_COLOR,
        bgcolor=SURFACE_LIGHT
    )
    new_config_visible = ft.Checkbox(label="Visível para o Motorista", value=True, fill_color=PRIMARY_COLOR)

    config_panel = ft.Container(
        content=ft.Column(
            [
                ft.Text("Gerenciamento de Tipos de Eventos", size=20, weight=ft.FontWeight.BOLD, color=TEXT_COLOR),
                ft.Divider(color=PRIMARY_COLOR),
                ft.Row([new_config_name, new_config_type, new_config_visible], vertical_alignment=ft.CrossAxisAlignment.CENTER),
                ft.ElevatedButton("Adicionar Novo Evento", icon=ft.icons.ADD, on_click=add_new_config, bgcolor=PRIMARY_COLOR, color=TEXT_COLOR),
                ft.Divider(height=20, color=ft.colors.TRANSPARENT),
                ft.Text("Configurações Ativas", size=18, color=TEXT_COLOR, weight=ft.FontWeight.W_500),
                config_list
            ],
            expand=True
        ),
        bgcolor=SURFACE_COLOR,
        padding=20,
        border_radius=12,
        expand=True
    )

    # --- SANDBOX MANAGEMENT PANEL ---
    sandbox_list = ft.Column(spacing=8, scroll=ft.ScrollMode.AUTO, expand=True)

    def reload_sandbox_ui():
        nonlocal sandbox_list
        load_companies()
        sandbox_list.controls.clear()
        for comp in DEMO_COMPANIES:
            cid = comp.get("id")
            def make_toggle(cid=cid):
                return lambda e: toggle_sandbox(cid, e.control.value)

            sandbox_list.controls.append(
                ft.Row([
                    ft.Text(comp.get("nome"), expand=True, color=TEXT_COLOR),
                    ft.Switch(label="Sandbox", value=(db.is_empresa_sandbox(cid) or bool(comp.get("sandbox"))), on_change=make_toggle(), active_color=WARNING_COLOR)
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN)
            )
        page.update()

    def toggle_sandbox(empresa_id, value):
        try:
            db.set_sandbox_empresa(empresa_id, bool(value))
            show_toast(f"Empresa {'marcada' if value else 'desmarcada'} como sandbox")
            reload_sandbox_ui()
        except Exception as ex:
            show_toast(f"Erro ao atualizar sandbox: {ex}", True)

    # Create company form only (vehicles and users managed in other UI panels)
    new_company_name = ft.TextField(label="Nome da Empresa", border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT)
    new_company_cnpj = ft.TextField(label="CNPJ (opcional)", border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT)

    def create_company(e):
        import uuid
        nome = new_company_name.value.strip()
        cnpj = new_company_cnpj.value.strip()
        if not nome:
            show_toast("Nome da empresa obrigatório", True)
            return
        try:
            cid = str(uuid.uuid4())
            body = {"id": cid, "nome": nome}
            if cnpj:
                body["cnpj"] = cnpj
            db._make_request("POST", "sf_empresas", body=body)
            show_toast("Empresa criada no Supabase")
            new_company_name.value = ""
            new_company_cnpj.value = ""
            load_companies(); reload_sandbox_ui(); page.update()
        except Exception as ex:
            show_toast(f"Erro ao criar empresa: {ex}", True)

    sandbox_panel = ft.Container(
        content=ft.Column([
            ft.Text("Sandbox Manager", size=20, weight=ft.FontWeight.BOLD, color=TEXT_COLOR),
            ft.Divider(color=PRIMARY_COLOR),
            ft.Text("Marcar empresas como sandbox para testes e simulações", color=TEXT_MUTED),
            sandbox_list,
            ft.Divider(),
            ft.Text("Criar nova Empresa (Supabase)", color=TEXT_COLOR),
            ft.Row([new_company_name, new_company_cnpj]),
            ft.ElevatedButton("Criar Empresa", on_click=create_company, bgcolor=PRIMARY_COLOR, color=TEXT_COLOR),
        ], spacing=10),
        bgcolor=SURFACE_COLOR,
        padding=20,
        border_radius=12,
        expand=True
    )

    # --- LANÇAMENTO DE EVENTOS ADMINISTRATIVOS ---
    admin_macro_type = ft.Dropdown(label="Evento Administrativo", options=[], border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT)
    admin_km = ft.TextField(label="KM Atual (Opcional)", keyboard_type=ft.KeyboardType.NUMBER, border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT, expand=True)
    admin_valor = ft.TextField(label="Valor Total (R$)", keyboard_type=ft.KeyboardType.NUMBER, border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT, expand=True)
    admin_desc = ft.TextField(label="Descrição / Detalhes", border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT)
    admin_data_hora = ft.TextField(
        label="Data e Hora (AAAA-MM-DD HH:MM:SS)",
        value=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        border_color=PRIMARY_COLOR,
        bgcolor=SURFACE_LIGHT
    )

    # Elementos para registro de Eventos Diários do Motorista
    admin_driver_dropdown = ft.Dropdown(label="Motorista", border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT)
    admin_daily_event_dropdown = ft.Dropdown(
        label="Evento Diário",
        options=[ft.dropdown.Option(ev) for ev in [
            "Retirada na garagem",
            "Chegada ao primeiro aluno",
            "Chegada a última escola",
            "Chegada a área de descanso",
            "Retorno a garagem principal",
            "Deslocamento não programado"
        ]],
        border_color=PRIMARY_COLOR,
        bgcolor=SURFACE_LIGHT
    )
    admin_daily_km = ft.TextField(label="KM", keyboard_type=ft.KeyboardType.NUMBER, border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT, expand=True)
    admin_daily_lat = ft.TextField(label="Lat (Opcional)", border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT, expand=True)
    admin_daily_lon = ft.TextField(label="Lon (Opcional)", border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT, expand=True)
    admin_daily_data_hora = ft.TextField(
        label="Data e Hora (AAAA-MM-DD HH:MM:SS)",
        value=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        border_color=PRIMARY_COLOR,
        bgcolor=SURFACE_LIGHT
    )

    def load_admin_types():
        # Carrega os tipos de macros
        admin_macro_type.options = [ft.dropdown.Option(cfg["nome"]) for cfg in macro_configs]
        if macro_configs:
            admin_macro_type.value = macro_configs[0]["nome"]
            
        # Carrega os motoristas da empresa atual
        motoristas = [u for u in usuarios if u.get("role") == "motorista"]
        admin_driver_dropdown.options = [ft.dropdown.Option(key=u["id"], text=u["nome"]) for u in motoristas]
        if motoristas:
            admin_driver_dropdown.value = motoristas[0]["id"]
        else:
            admin_driver_dropdown.value = None
            
        # Carrega os motoristas no filtro de relatórios
        report_driver_filter.options = [
            ft.dropdown.Option(key="ALL", text="(Todos os Motoristas)")
        ] + [ft.dropdown.Option(key=u["id"], text=u["nome"]) for u in motoristas]
        report_driver_filter.value = "ALL"
            
        page.update()

    def register_admin_event(e):
        nome = admin_macro_type.value
        km = admin_km.value
        valor = admin_valor.value
        desc = admin_desc.value
        dt_str = admin_data_hora.value

        if not nome:
            show_toast("Selecione um tipo de evento!", True)
            return
        if not valor:
            show_toast("Digite o valor do evento!", True)
            return

        try:
            # Converte a data/hora local digitada para UTC antes de salvar
            data_hora_iso = _parse_local_dt(dt_str).isoformat()
        except ValueError:
            show_toast("Formato de data e hora inválido! Use o padrão AAAA-MM-DD HH:MM:SS", True)
            return

        try:
            km_val = float(km) if km else None
            valor_val = float(valor)
        except ValueError:
            show_toast("Valores numéricos inválidos!", True)
            return

        try:
            db.register_macro_event(
                evento_nome=nome,
                km_atual=km_val,
                valor_total=valor_val,
                descricao=desc,
                empresa_id=current_empresa_id,
                data_hora=data_hora_iso
            )
            show_toast("Evento administrativo registrado!")
            admin_km.value = ""
            admin_valor.value = ""
            admin_desc.value = ""
            admin_data_hora.value = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            load_data()
            reload_reports_ui()
        except Exception as ex:
            show_toast(f"Erro ao salvar evento administrativo: {ex}", True)

    def register_daily_admin_event(e):
        driver_id = admin_driver_dropdown.value
        nome_evento = admin_daily_event_dropdown.value
        km = admin_daily_km.value
        dt_str = admin_daily_data_hora.value
        lat = admin_daily_lat.value
        lon = admin_daily_lon.value

        if not driver_id:
            show_toast("Selecione um motorista!", True)
            return
        if not nome_evento:
            show_toast("Selecione o tipo de evento!", True)
            return
        if not km:
            show_toast("Digite o KM atual!", True)
            return

        try:
            data_hora_iso = _parse_local_dt(dt_str).isoformat()
        except ValueError:
            show_toast("Formato de data e hora inválido! Use o padrão AAAA-MM-DD HH:MM:SS", True)
            return

        try:
            km_val = float(km)
            lat_val = float(lat) if lat else 0.0
            lon_val = float(lon) if lon else 0.0
        except ValueError:
            show_toast("Valores numéricos inválidos!", True)
            return

        try:
            db.register_daily_event(
                nome_evento=nome_evento,
                km_atual=km_val,
                latitude=lat_val,
                longitude=lon_val,
                empresa_id=current_empresa_id,
                usuario_id=driver_id,
                data_hora=data_hora_iso
            )
            show_toast("Evento diário do motorista registrado!")
            admin_daily_km.value = ""
            admin_daily_lat.value = ""
            admin_daily_lon.value = ""
            admin_daily_data_hora.value = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            load_data()
            reload_reports_ui()
        except Exception as ex:
            show_toast(f"Erro ao salvar evento diário: {ex}", True)

    admin_tabs = ft.Tabs(
        selected_index=0,
        tabs=[
            ft.Tab(
                text="Despesas",
                icon=ft.icons.MONEY_OFF,
                content=ft.Column(
                    [
                        ft.Text("Registrar Despesa", size=15, weight=ft.FontWeight.BOLD, color=TEXT_COLOR),
                        admin_macro_type,
                        ft.Row([admin_km, admin_valor], spacing=10),
                        admin_data_hora,
                        admin_desc,
                        ft.ElevatedButton("Salvar Despesa", icon=ft.icons.SAVE, on_click=register_admin_event, bgcolor=ACCENT_COLOR, color=TEXT_COLOR)
                    ],
                    spacing=10,
                    scroll=ft.ScrollMode.AUTO
                )
            ),
            ft.Tab(
                text="Motorista",
                icon=ft.icons.ROUTE,
                content=ft.Column(
                    [
                        ft.Text("Evento Diário do Motorista", size=15, weight=ft.FontWeight.BOLD, color=TEXT_COLOR),
                        admin_driver_dropdown,
                        admin_daily_event_dropdown,
                        ft.Row([admin_daily_km, admin_daily_lat, admin_daily_lon], spacing=5),
                        admin_daily_data_hora,
                        ft.ElevatedButton("Salvar Rastreamento", icon=ft.icons.SAVE, on_click=register_daily_admin_event, bgcolor=PRIMARY_COLOR, color=TEXT_COLOR)
                    ],
                    spacing=10,
                    scroll=ft.ScrollMode.AUTO
                )
            )
        ],
        expand=True,
        label_color=PRIMARY_COLOR,
        indicator_color=PRIMARY_COLOR
    )

    admin_panel = ft.Container(
        content=admin_tabs,
        bgcolor=SURFACE_COLOR,
        padding=15,
        border_radius=12,
        width=360
    )

    # --- RELATÓRIOS E ANÁLISE DE CUSTOS ---
    relatorio_resultados = ft.Container(expand=True)
    txt_custo_total = ft.Text("Custo Total Acumulado: R$ 0,00", size=18, weight=ft.FontWeight.BOLD, color=TEXT_COLOR)
    txt_km_total = ft.Text("Quilometragem Percorrida: 0 KM", size=18, weight=ft.FontWeight.BOLD, color=TEXT_COLOR)

    # Inputs para filtro de período
    filter_start = ft.TextField(label="Data Inicial (AAAA-MM-DD)", value=(datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d"), border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT, expand=True)
    filter_end = ft.TextField(label="Data Final (AAAA-MM-DD)", value=datetime.now().strftime("%Y-%m-%d"), border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT, expand=True)
    report_driver_filter = ft.Dropdown(
        label="Filtrar por Motorista",
        border_color=PRIMARY_COLOR,
        bgcolor=SURFACE_LIGHT,
        expand=True
    )

    def confirm_delete_macro(m):
        def delete_action(e):
            try:
                db.delete_macro_event(m["id"])
                show_toast("Despesa excluída com sucesso!")
                dialog.open = False
                page.update()
                reload_reports_ui()
            except Exception as ex:
                show_toast(f"Erro ao excluir despesa: {ex}", True)
        
        dialog = ft.AlertDialog(
            title=ft.Text("Confirmar Exclusão"),
            content=ft.Text(f"Deseja realmente excluir a despesa '{m['evento_nome']}' de R$ {m['valor_total']:.2f}?"),
            actions=[
                ft.TextButton("Cancelar", on_click=lambda e: setattr(dialog, "open", False) or page.update()),
                ft.TextButton("Excluir", on_click=delete_action, style=ft.ButtonStyle(color=ft.colors.RED_400))
            ],
            actions_alignment=ft.MainAxisAlignment.END
        )
        page.overlay.append(dialog)
        dialog.open = True
        page.update()

    def edit_macro_dialog(m):
        edit_nome = ft.Dropdown(
            label="Tipo de Lançamento",
            options=[ft.dropdown.Option(cfg["nome"]) for cfg in macro_configs],
            value=m["evento_nome"],
            bgcolor=SURFACE_LIGHT,
            color=TEXT_COLOR,
            border_color=PRIMARY_COLOR
        )
        edit_km = ft.TextField(label="KM Atual", value=str(m["km_atual"]) if m["km_atual"] is not None else "", border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT)
        edit_litros = ft.TextField(label="Litros", value=str(m["litros"]) if m["litros"] is not None else "", border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT)
        edit_valor_litro = ft.TextField(label="Valor por Litro", value=str(m["valor_por_litro"]) if m["valor_por_litro"] is not None else "", border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT)
        edit_valor_total = ft.TextField(label="Valor Total", value=str(m["valor_total"]), border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT)
        edit_desc = ft.TextField(label="Descrição", value=m["descricao"] or "", border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT)
        
        orig_dt = m["data_hora"]
        try:
            dt_str = _format_local(orig_dt, "%Y-%m-%d %H:%M:%S")
        except Exception:
            dt_str = orig_dt

        edit_dt = ft.TextField(label="Data e Hora", value=dt_str, border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT)

        def on_edit_macro_change(e):
            is_abast = edit_nome.value == "Abastecimento"
            edit_litros.visible = is_abast
            edit_valor_litro.visible = is_abast
            edit_valor_total.read_only = is_abast
            dialog.update()

        edit_nome.on_change = on_edit_macro_change

        is_abast = m["evento_nome"] == "Abastecimento"
        edit_litros.visible = is_abast
        edit_valor_litro.visible = is_abast
        edit_valor_total.read_only = is_abast

        def save_changes(e):
            try:
                nome = edit_nome.value
                km_val = float(edit_km.value) if edit_km.value else None
                litros_val = float(edit_litros.value) if (edit_litros.value and is_abast) else None
                valor_litro_val = float(edit_valor_litro.value) if (edit_valor_litro.value and is_abast) else None
                
                if is_abast:
                    if not litros_val or not valor_litro_val:
                        show_toast("Litros e Valor por Litro são obrigatórios no Abastecimento!", True)
                        return
                    total_val = litros_val * valor_litro_val
                else:
                    if not edit_valor_total.value:
                        show_toast("Valor Total é obrigatório!", True)
                        return
                    total_val = float(edit_valor_total.value)

                data_hora_iso = _parse_local_dt(edit_dt.value).isoformat()
                
                db.update_macro_event(
                    event_id=m["id"],
                    evento_nome=nome,
                    km_atual=km_val,
                    litros=litros_val,
                    valor_por_litro=valor_litro_val,
                    descricao=edit_desc.value,
                    valor_total=total_val,
                    data_hora=data_hora_iso
                )
                show_toast("Despesa atualizada com sucesso!")
                dialog.open = False
                page.update()
                reload_reports_ui()
            except ValueError:
                show_toast("Verifique os valores numéricos e o formato de data (AAAA-MM-DD HH:MM:SS)!", True)
            except Exception as ex:
                show_toast(f"Erro ao salvar alterações: {ex}", True)

        dialog = ft.AlertDialog(
            title=ft.Text("Editar Lançamento de Despesa"),
            content=ft.Column(
                [
                    edit_nome,
                    edit_km,
                    edit_litros,
                    edit_valor_litro,
                    edit_valor_total,
                    edit_desc,
                    edit_dt
                ],
                spacing=10,
                width=400,
                height=450,
                scroll=ft.ScrollMode.AUTO
            ),
            actions=[
                ft.TextButton("Cancelar", on_click=lambda e: setattr(dialog, "open", False) or page.update()),
                ft.TextButton("Salvar", on_click=save_changes)
            ],
            actions_alignment=ft.MainAxisAlignment.END
        )
        page.overlay.append(dialog)
        dialog.open = True
        page.update()

    def confirm_delete_daily(d):
        def delete_action(e):
            try:
                db.delete_daily_event(d["id"])
                show_toast("Evento diário excluído com sucesso!")
                dialog.open = False
                page.update()
                reload_reports_ui()
            except Exception as ex:
                show_toast(f"Erro ao excluir evento: {ex}", True)
        
        dialog = ft.AlertDialog(
            title=ft.Text("Confirmar Exclusão"),
            content=ft.Text(f"Deseja realmente excluir o evento '{d['nome_evento']}' do KM {d['km_atual']}?"),
            actions=[
                ft.TextButton("Cancelar", on_click=lambda e: setattr(dialog, "open", False) or page.update()),
                ft.TextButton("Excluir", on_click=delete_action, style=ft.ButtonStyle(color=ft.colors.RED_400))
            ],
            actions_alignment=ft.MainAxisAlignment.END
        )
        page.overlay.append(dialog)
        dialog.open = True
        page.update()

    def edit_daily_dialog(d):
        edit_nome = ft.Dropdown(
            label="Evento Diário",
            options=[ft.dropdown.Option(ev) for ev in [
                "Retirada na garagem",
                "Chegada ao primeiro aluno",
                "Chegada a última escola",
                "Chegada a área de descanso",
                "Retorno a garagem principal",
                "Deslocamento não programado"
            ]],
            value=d["nome_evento"],
            bgcolor=SURFACE_LIGHT,
            color=TEXT_COLOR,
            border_color=PRIMARY_COLOR
        )
        
        motoristas = [u for u in usuarios if u.get("role") == "motorista"]
        edit_driver = ft.Dropdown(
            label="Motorista",
            options=[ft.dropdown.Option(key=u["id"], text=u["nome"]) for u in motoristas],
            value=d.get("usuario_id"),
            bgcolor=SURFACE_LIGHT,
            color=TEXT_COLOR,
            border_color=PRIMARY_COLOR
        )

        edit_km = ft.TextField(label="KM", value=str(d["km_atual"]), border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT)
        edit_lat = ft.TextField(label="Latitude", value=str(d["latitude"]) if d["latitude"] is not None else "", border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT)
        edit_lon = ft.TextField(label="Longitude", value=str(d["longitude"]) if d["longitude"] is not None else "", border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT)
        
        orig_dt = d["data_hora"]
        try:
            dt_str = _format_local(orig_dt, "%Y-%m-%d %H:%M:%S")
        except Exception:
            dt_str = orig_dt

        edit_dt = ft.TextField(label="Data e Hora", value=dt_str, border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT)

        def save_changes(e):
            try:
                nome = edit_nome.value
                driver_id = edit_driver.value
                km_val = float(edit_km.value)
                lat_val = float(edit_lat.value) if edit_lat.value else 0.0
                lon_val = float(edit_lon.value) if edit_lon.value else 0.0

                data_hora_iso = _parse_local_dt(edit_dt.value).isoformat()
                
                db.update_daily_event(
                    event_id=d["id"],
                    nome_evento=nome,
                    km_atual=km_val,
                    latitude=lat_val,
                    longitude=lon_val,
                    data_hora=data_hora_iso,
                    usuario_id=driver_id
                )
                show_toast("Evento diário atualizado com sucesso!")
                dialog.open = False
                page.update()
                reload_reports_ui()
            except ValueError:
                show_toast("Verifique os valores numéricos e o formato de data (AAAA-MM-DD HH:MM:SS)!", True)
            except Exception as ex:
                show_toast(f"Erro ao salvar alterações: {ex}", True)

        dialog = ft.AlertDialog(
            title=ft.Text("Editar Evento Diário (Motorista)"),
            content=ft.Column(
                [
                    edit_nome,
                    edit_driver,
                    edit_km,
                    edit_lat,
                    edit_lon,
                    edit_dt
                ],
                spacing=10,
                width=400,
                height=450,
                scroll=ft.ScrollMode.AUTO
            ),
            actions=[
                ft.TextButton("Cancelar", on_click=lambda e: setattr(dialog, "open", False) or page.update()),
                ft.TextButton("Salvar", on_click=save_changes)
            ],
            actions_alignment=ft.MainAxisAlignment.END
        )
        page.overlay.append(dialog)
        dialog.open = True
        page.update()

    def reload_reports_ui(e=None):
        load_data()
        
        try:
            start_dt = _parse_local_dt(filter_start.value + " 00:00:00").isoformat()
            end_dt = _parse_local_dt(filter_end.value + " 23:59:59").isoformat()
        except ValueError:
            show_toast("Formato de data inválido! Use AAAA-MM-DD", True)
            return

        # Filtro de motorista
        selected_driver = report_driver_filter.value

        # Filtro de macros
        macros_filtrados = [
            m for m in macro_events 
            if start_dt <= m["data_hora"] <= end_dt
        ]
        if selected_driver and selected_driver != "ALL":
            macros_filtrados = [m for m in macros_filtrados if m.get("usuario_id") == selected_driver]
        
        # Filtro de diarios
        diarios_filtrados = [
            d for d in daily_events
            if start_dt <= d["data_hora"] <= end_dt
        ]
        if selected_driver and selected_driver != "ALL":
            diarios_filtrados = [d for d in diarios_filtrados if d.get("usuario_id") == selected_driver]

        custo_total = sum(m["valor_total"] for m in macros_filtrados)
        
        # Calcular KM total percorrido no período
        km_percorrido = 0
        if len(diarios_filtrados) >= 2:
            km_percorrido = float(diarios_filtrados[-1]["km_atual"]) - float(diarios_filtrados[0]["km_atual"])

        # Calcular totais automáticos para comparação
        breadcrumbs_total = sum(float(d.get("km_breadcrumbs") or 0.0) for d in diarios_filtrados)
        snap_road_total = sum(float(d.get("km_snap_road") or 0.0) for d in diarios_filtrados)

        txt_custo_total.value = f"Custo Total Acumulado: R$ {custo_total:,.2f}"
        txt_km_total.value = (
            f"Quilometragem Percorrida:\n"
            f"• Digitado (Motorista): {km_percorrido:,.1f} KM\n"
            f"• GPS (Breadcrumbs): {breadcrumbs_total:,.1f} KM\n"
            f"• Rota (Snap-to-Road): {snap_road_total:,.1f} KM"
        )

        col_despesas = ft.Column(spacing=10, scroll=ft.ScrollMode.AUTO, expand=True)
        col_diarios = ft.Column(spacing=10, scroll=ft.ScrollMode.AUTO, expand=True)

        # Adicionar cards de despesas
        if not macros_filtrados:
            col_despesas.controls.append(ft.Text("Nenhuma despesa registrada neste período.", color=TEXT_MUTED))
        for m in macros_filtrados:
            dt = _format_local(m["data_hora"], "%d/%m/%Y %H:%M")
            
            def make_edit_handler(item=m):
                return lambda e: edit_macro_dialog(item)
            def make_delete_handler(item=m):
                return lambda e: confirm_delete_macro(item)

            col_despesas.controls.append(
                ft.Container(
                    content=ft.Row(
                        [
                            ft.Icon(ft.icons.MONEY_OFF if "Abastecimento" not in m["evento_nome"] else ft.icons.LOCAL_GAS_STATION, color=ft.colors.RED_400, size=24),
                            ft.Column(
                                [
                                    ft.Row([
                                        ft.Text(f"{m['evento_nome']}", color=TEXT_COLOR, size=14, weight=ft.FontWeight.BOLD, expand=True),
                                        ft.Text(dt, color=TEXT_MUTED, size=11),
                                    ]),
                                    ft.Text(f"Valor: R$ {m['valor_total']:.2f}" + (f" | KM: {int(m['km_atual'])}" if m['km_atual'] else ""), color=ACCENT_COLOR, size=13, weight=ft.FontWeight.W_500),
                                    ft.Text(f"{m['descricao'] or ''}", color=TEXT_MUTED, size=12) if m['descricao'] else ft.Container(),
                                ],
                                expand=True,
                                spacing=4
                            ),
                            ft.Row(
                                [
                                    ft.IconButton(ft.icons.EDIT_OUTLINED, icon_color=PRIMARY_COLOR, icon_size=18, on_click=make_edit_handler(), tooltip="Editar"),
                                    ft.IconButton(ft.icons.DELETE_OUTLINE_ROUNDED, icon_color=ft.colors.RED_400, icon_size=18, on_click=make_delete_handler(), tooltip="Excluir")
                                ],
                                spacing=0
                            )
                        ],
                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN
                    ),
                    bgcolor=SURFACE_LIGHT,
                    padding=12,
                    border_radius=8
                )
            )

        # Adicionar cards de diários
        if not diarios_filtrados:
            col_diarios.controls.append(ft.Text("Nenhum evento de jornada registrado neste período.", color=TEXT_MUTED))
        
        user_map = {u["id"]: u["nome"] for u in usuarios}
        for d in diarios_filtrados:
            dt = _format_local(d["data_hora"], "%d/%m/%Y %H:%M")
            driver_name = user_map.get(d.get("usuario_id"), "Desconhecido")

            def make_edit_daily_handler(item=d):
                return lambda e: edit_daily_dialog(item)
            def make_delete_daily_handler(item=d):
                return lambda e: confirm_delete_daily(item)

            col_diarios.controls.append(
                ft.Container(
                    content=ft.Row(
                        [
                            ft.Icon(ft.icons.LOCATION_ON, color=PRIMARY_COLOR, size=24),
                            ft.Column(
                                [
                                    ft.Row([
                                        ft.Text(f"{d['nome_evento']}", color=TEXT_COLOR, size=14, weight=ft.FontWeight.BOLD, expand=True),
                                        ft.Text(dt, color=TEXT_MUTED, size=11),
                                    ]),
                                    ft.Text(
                                        f"Motorista: {driver_name} | Digitado: {d['km_atual']} "
                                        f"| Breadcrumbs: {float(d.get('km_breadcrumbs') or 0.0):.2f} KM "
                                        f"| Snap-to-Road: {float(d.get('km_snap_road') or 0.0):.2f} KM", 
                                        color=TEXT_MUTED, size=12
                                    ),
                                    ft.Text(f"Lat: {d['latitude']} | Lon: {d['longitude']}", color=TEXT_MUTED, size=11) if (d['latitude'] or d['longitude']) else ft.Container()
                                ],
                                expand=True,
                                spacing=4
                            ),
                            ft.Row(
                                [
                                    ft.IconButton(ft.icons.EDIT_OUTLINED, icon_color=PRIMARY_COLOR, icon_size=18, on_click=make_edit_daily_handler(), tooltip="Editar"),
                                    ft.IconButton(ft.icons.DELETE_OUTLINE_ROUNDED, icon_color=ft.colors.RED_400, icon_size=18, on_click=make_delete_daily_handler(), tooltip="Excluir")
                                ],
                                spacing=0
                            )
                        ],
                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN
                    ),
                    bgcolor=SURFACE_LIGHT,
                    padding=12,
                    border_radius=8
                )
            )

        results_tab = ft.Tabs(
            selected_index=0,
            tabs=[
                ft.Tab(text="Despesas (Macros)", icon=ft.icons.MONEY_OFF, content=col_despesas),
                ft.Tab(text="Jornada (Diários)", icon=ft.icons.ROUTE, content=col_diarios)
            ],
            expand=True,
            label_color=PRIMARY_COLOR,
            indicator_color=PRIMARY_COLOR
        )

        relatorio_resultados.content = results_tab
        page.update()


    # --- CÁLCULO DE CUSTO POR TRECHOS ---
    trecho_de = ft.Dropdown(label="Partida (Evento A)", options=[], border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT)
    trecho_para = ft.Dropdown(label="Destino (Evento B)", options=[], border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT)
    result_trecho_display = ft.Container(padding=15, border_radius=8, bgcolor=SURFACE_LIGHT)

    def load_trechos_dropdowns():
        event_names = list(set([d["nome_evento"] for d in daily_events]))
        trecho_de.options = [ft.dropdown.Option(x) for x in event_names]
        trecho_para.options = [ft.dropdown.Option(x) for x in event_names]
        page.update()

    def calcular_custo_trecho(e):
        de_evento = trecho_de.value
        para_evento = trecho_para.value

        if not de_evento or not para_evento:
            show_toast("Selecione os eventos de partida e destino!", True)
            return

        # 1. Encontrar todos os trechos entre esses eventos na ordem temporal em pares
        total_km_deslocado = 0
        matching_trips = 0
        discrepancy_detected = False
        discrepant_details = []
        
        # Encontra instâncias onde 'de_evento' precede 'para_evento' temporalmente
        sorted_diarios = sorted(daily_events, key=lambda x: (x["data_hora"], x["seq_ordenacao"]))
        
        i = 0
        n = len(sorted_diarios)
        while i < n:
            if sorted_diarios[i]["nome_evento"] == de_evento:
                # Procurar o próximo para_evento
                j = i + 1
                found_para = False
                while j < n:
                    if sorted_diarios[j]["nome_evento"] == de_evento:
                        # Encontramos outro de_evento antes do para_evento.
                        # Ignoramos o de_evento anterior (i) e começamos a buscar a partir deste novo (j).
                        break
                    if sorted_diarios[j]["nome_evento"] == para_evento:
                        # Achamos o par!
                        diff_km = float(sorted_diarios[j]["km_atual"]) - float(sorted_diarios[i]["km_atual"])
                        if diff_km < 0:
                            discrepancy_detected = True
                            dt_i = _format_local(sorted_diarios[i]["data_hora"], "%d/%m %H:%M")
                            dt_j = _format_local(sorted_diarios[j]["data_hora"], "%d/%m %H:%M")
                            discrepant_details.append(
                                f"KM negativo ({diff_km:.1f} KM) entre {dt_i} e {dt_j}"
                            )
                        total_km_deslocado += diff_km
                        matching_trips += 1
                        found_para = True
                        i = j # Avança para depois do destino
                        break
                    j += 1
                if not found_para:
                    if j < n and sorted_diarios[j]["nome_evento"] == de_evento:
                        i = j
                    else:
                        i += 1
            else:
                i += 1
        
        # 2. Calcular custo médio por KM geral (Total abastecido e manutenções / Distância total no banco)
        total_costs = sum(float(m["valor_total"]) for m in macro_events if m["evento_nome"] in ["Abastecimento", "Manutenções"])
        
        # Distância total percorrida geral no banco
        min_km = min([float(d["km_atual"]) for d in daily_events]) if daily_events else 0
        max_km = max([float(d["km_atual"]) for d in daily_events]) if daily_events else 0
        total_kms_database = max_km - min_km
        
        custo_por_km = 0.0
        if total_kms_database > 0:
            custo_por_km = total_costs / total_kms_database

        custo_trecho_total = total_km_deslocado * custo_por_km

        if discrepancy_detected:
            result_trecho_display.content = ft.Column(
                [
                    ft.Row(
                        [
                            ft.Icon(ft.icons.ERROR_ROUNDED, color=ft.colors.RED_500, size=24),
                            ft.Text("Erro nos registros / Discrepância", color=ft.colors.RED_400, size=15, weight=ft.FontWeight.BOLD)
                        ],
                        spacing=5
                    ),
                    ft.Column(
                        [ft.Text(det, color=TEXT_MUTED, size=12) for det in discrepant_details],
                        spacing=2
                    ),
                    ft.Divider(color=ft.colors.RED_900),
                    ft.Text(f"KM Acumulado calculado: {total_km_deslocado:.2f} KM", size=13, color=TEXT_COLOR)
                ],
                spacing=8
            )
        else:
            result_trecho_display.content = ft.Column(
                [
                    ft.Text(f"Trechos analisados: {matching_trips}", size=14, color=TEXT_COLOR),
                    ft.Text(f"Quilometragem Total Acumulada no Trecho: {total_km_deslocado:.2f} KM", size=16, weight=ft.FontWeight.BOLD, color=TEXT_COLOR),
                    ft.Text(f"Custo por KM Geral Estimado: R$ {custo_por_km:.2f}/KM", size=14, color=ACCENT_COLOR),
                    ft.Divider(color=TEXT_MUTED),
                    ft.Text(f"Custo Total Estimado do Trecho: R$ {custo_trecho_total:,.2f}", size=18, weight=ft.FontWeight.BOLD, color=ACCENT_COLOR)
                ]
            )
        page.update()

    reports_panel = ft.Container(
        content=ft.Row(
            [
                # Coluna Filtros e Histórico
                ft.Column(
                    [
                        ft.Text("Relatório de Custos Gerais", size=20, weight=ft.FontWeight.BOLD, color=TEXT_COLOR),
                        ft.Divider(color=PRIMARY_COLOR),
                        ft.Row([filter_start, filter_end, report_driver_filter], spacing=10),
                        ft.ElevatedButton("Filtrar Período", icon=ft.icons.FILTER_ALT, on_click=reload_reports_ui, bgcolor=PRIMARY_COLOR, color=TEXT_COLOR),
                        ft.Divider(height=10, color=ft.colors.TRANSPARENT),
                        txt_custo_total,
                        txt_km_total,
                        ft.Divider(height=10, color=ft.colors.TRANSPARENT),
                        relatorio_resultados
                    ],
                    expand=True
                ),
                ft.VerticalDivider(width=20, color=PRIMARY_COLOR),
                # Coluna Trechos
                ft.Column(
                    [
                        ft.Text("Análise de Custo por Trecho", size=20, weight=ft.FontWeight.BOLD, color=TEXT_COLOR),
                        ft.Divider(color=PRIMARY_COLOR),
                        trecho_de,
                        trecho_para,
                        ft.ElevatedButton("Calcular Deslocamento do Trecho", icon=ft.icons.CALCULATE, on_click=calcular_custo_trecho, bgcolor=ACCENT_COLOR, color=TEXT_COLOR),
                        ft.Divider(height=20, color=ft.colors.TRANSPARENT),
                        result_trecho_display
                    ],
                    width=400
                )
            ]
        ),
        bgcolor=SURFACE_COLOR,
        padding=20,
        border_radius=12,
        expand=True
    )

    # --- GERENCIAMENTO DE VEÍCULOS ---
    veiculos_list_ui = ft.Column(spacing=10, scroll=ft.ScrollMode.AUTO, expand=True)

    def reload_veiculos_ui():
        load_data()
        veiculos_list_ui.controls.clear()
        
        for v in veiculos:
            def make_delete_veh_handler(veh_id=v["id"], placa=v["placa"]):
                return lambda e: confirm_delete_veiculo(veh_id, placa)
            def make_edit_veh_handler(veh=v):
                return lambda e: edit_veiculo_dialog(veh)

            veiculos_list_ui.controls.append(
                ft.Container(
                    content=ft.Row(
                        [
                            ft.Icon(ft.icons.LOCAL_SHIPPING, color=PRIMARY_COLOR),
                            ft.Column(
                                [
                                    ft.Text(f"Placa: {v['placa']}", color=TEXT_COLOR, size=16, weight=ft.FontWeight.BOLD),
                                    ft.Text(f"Marca: {v.get('marca', '---')} | Modelo: {v.get('modelo', '---')}", color=TEXT_MUTED, size=13),
                                ],
                                spacing=2,
                                expand=True
                            ),
                            ft.Row(
                                [
                                    ft.IconButton(ft.icons.EDIT_OUTLINED, icon_color=PRIMARY_COLOR, on_click=make_edit_veh_handler(), tooltip="Editar Veículo"),
                                    ft.IconButton(ft.icons.DELETE_OUTLINE_ROUNDED, icon_color=ft.colors.RED_400, on_click=make_delete_veh_handler(), tooltip="Excluir Veículo")
                                ],
                                spacing=0
                            )
                        ],
                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN
                    ),
                    bgcolor=SURFACE_LIGHT,
                    padding=10,
                    border_radius=8
                )
            )
        page.update()

    def edit_veiculo_dialog(v):
        edit_placa = ft.TextField(label="Placa", value=v["placa"], border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT)
        edit_marca = ft.TextField(label="Marca", value=v.get("marca") or "", border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT)
        edit_modelo = ft.TextField(label="Modelo", value=v.get("modelo") or "", border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT)
        
        def save_veh_changes(e):
            placa = edit_placa.value.strip()
            marca = edit_marca.value.strip()
            modelo = edit_modelo.value.strip()
            if not placa:
                show_toast("Placa é obrigatória!", True)
                return
            try:
                db.update_veiculo(v["id"], placa, marca, modelo)
                show_toast("Veículo atualizado com sucesso!")
                dialog.open = False
                page.update()
                reload_veiculos_ui()
                if selected_driver_id:
                    show_driver_config(selected_driver_id, selected_driver_name)
            except Exception as ex:
                show_toast(f"Erro ao atualizar veículo: {ex}", True)
                
        dialog = ft.AlertDialog(
            title=ft.Text("Editar Veículo"),
            content=ft.Column(
                [edit_placa, edit_marca, edit_modelo],
                spacing=10,
                width=350,
                height=250,
                scroll=ft.ScrollMode.AUTO
            ),
            actions=[
                ft.TextButton("Cancelar", on_click=lambda e: setattr(dialog, "open", False) or page.update()),
                ft.TextButton("Salvar", on_click=save_veh_changes)
            ],
            actions_alignment=ft.MainAxisAlignment.END
        )
        page.overlay.append(dialog)
        dialog.open = True
        page.update()

    def add_new_vehicle(e):
        placa = new_veh_placa.value.strip()
        marca = new_veh_marca.value.strip()
        modelo = new_veh_modelo.value.strip()

        if not placa:
            show_toast("Placa do veículo é obrigatória!", True)
            return

        try:
            db.add_veiculo(placa, marca, modelo, current_empresa_id)
            show_toast(f"Veículo '{placa}' cadastrado com sucesso!")
            new_veh_placa.value = ""
            new_veh_marca.value = ""
            new_veh_modelo.value = ""
            reload_veiculos_ui()
            if selected_driver_id:
                show_driver_config(selected_driver_id, selected_driver_name)
        except Exception as ex:
            show_toast(f"Erro ao criar veículo: {ex}", True)

    def confirm_delete_veiculo(veh_id, placa):
        def delete_action(e):
            try:
                db.delete_veiculo(veh_id)
                show_toast("Veículo excluído com sucesso!")
                dialog.open = False
                page.update()
                reload_veiculos_ui()
                if selected_driver_id:
                    show_driver_config(selected_driver_id, selected_driver_name)
            except Exception as ex:
                show_toast(f"Erro ao excluir veículo: {ex}", True)
        
        dialog = ft.AlertDialog(
            title=ft.Text("Confirmar Exclusão"),
            content=ft.Text(f"Deseja realmente excluir o veículo de placa '{placa}'?"),
            actions=[
                ft.TextButton("Cancelar", on_click=lambda e: setattr(dialog, "open", False) or page.update()),
                ft.TextButton("Excluir", on_click=delete_action, style=ft.ButtonStyle(color=ft.colors.RED_400))
            ],
            actions_alignment=ft.MainAxisAlignment.END
        )
        page.overlay.append(dialog)
        dialog.open = True
        page.update()

    new_veh_placa = ft.TextField(label="Placa (ex: ABC-1234)", border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT, expand=True)
    new_veh_marca = ft.TextField(label="Marca (ex: Fiat)", border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT, expand=True)
    new_veh_modelo = ft.TextField(label="Modelo (ex: Ducato)", border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT, expand=True)

    veiculos_panel = ft.Container(
        content=ft.Column(
            [
                ft.Text("Gerenciamento de Veículos da Empresa", size=20, weight=ft.FontWeight.BOLD, color=TEXT_COLOR),
                ft.Divider(color=PRIMARY_COLOR),
                ft.Row([new_veh_placa, new_veh_marca, new_veh_modelo], vertical_alignment=ft.CrossAxisAlignment.CENTER),
                ft.ElevatedButton("Cadastrar Veículo", icon=ft.icons.ADD_ROAD, on_click=add_new_vehicle, bgcolor=PRIMARY_COLOR, color=TEXT_COLOR),
                ft.Divider(height=20, color=ft.colors.TRANSPARENT),
                ft.Text("Veículos Cadastrados", size=18, color=TEXT_COLOR, weight=ft.FontWeight.W_500),
                veiculos_list_ui
            ],
            expand=True
        ),
        bgcolor=SURFACE_COLOR,
        padding=20,
        border_radius=12,
        expand=True
    )

    # --- GERENCIAMENTO DE USUÁRIOS ---
    users_list_ui = ft.Column(spacing=10, scroll=ft.ScrollMode.AUTO, expand=True)
    selected_driver_id = None
    selected_driver_name = ""

    driver_detail_title = ft.Text("", size=18, weight=ft.FontWeight.BOLD, color=TEXT_COLOR)
    driver_vehicle_dropdown = ft.Dropdown(label="Veículo Designado", border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT)
    driver_events_col = ft.Column(spacing=5, scroll=ft.ScrollMode.AUTO, expand=True)

    def show_driver_config(u_id, u_nome):
        nonlocal selected_driver_id, selected_driver_name
        selected_driver_id = u_id
        selected_driver_name = u_nome
        
        driver_detail_title.value = f"Configurações: {u_nome}"
        
        load_data()
        veh_atual = db.get_driver_veiculo(u_id)
        
        opcoes_veic = [ft.dropdown.Option(key="NONE", text="(Nenhum veículo designado)")]
        for v in veiculos:
            opcoes_veic.append(ft.dropdown.Option(key=v["id"], text=f"{v['placa']} - {v.get('marca','')} {v.get('modelo','')}".strip()))
        
        driver_vehicle_dropdown.options = opcoes_veic
        driver_vehicle_dropdown.value = veh_atual["id"] if veh_atual else "NONE"
        
        def on_veh_designation_change(e):
            nonlocal selected_driver_id
            novo_veh = driver_vehicle_dropdown.value
            if novo_veh == "NONE":
                novo_veh = None
            db.update_usuario_veiculo(selected_driver_id, novo_veh)
            show_toast("Veículo designado atualizado!")
            reload_users_ui()
            
        driver_vehicle_dropdown.on_change = on_veh_designation_change
        
        evs_atribuidos = db.get_usuario_event_configs(u_id)
        atribuidos_map = {ev["id"]: ev for ev in evs_atribuidos}
        
        driver_events_col.controls.clear()
        driver_events_col.controls.append(ft.Text("Eventos Diários (Jornada) - Defina a Ordem", size=14, weight=ft.FontWeight.BOLD, color=PRIMARY_COLOR))
        
        config_diarias = [c for c in macro_configs if c["tipo"] == "diario"]
        if not config_diarias:
            config_diarias = [c for c in db.get_event_configs(empresa_id=current_empresa_id) if c["tipo"] == "diario"]
            
        check_controls = {}
        seq_controls = {}
        part_controls = {}
        
        for cfg in config_diarias:
            is_checked = cfg["id"] in atribuidos_map
            ordem_val = str(atribuidos_map[cfg["id"]]["ordem_sequencia"]) if is_checked else "0"
            part_val = bool(atribuidos_map[cfg["id"]].get("participa_sequencia", True)) if is_checked else True
            
            chk = ft.Checkbox(value=is_checked, fill_color=PRIMARY_COLOR)
            seq = ft.TextField(value=ordem_val, keyboard_type=ft.KeyboardType.NUMBER, border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT, width=50, height=35, content_padding=5)
            part = ft.Checkbox(label="Seq?", value=part_val, fill_color=PRIMARY_COLOR)
            
            check_controls[cfg["id"]] = chk
            seq_controls[cfg["id"]] = seq
            part_controls[cfg["id"]] = part
            
            driver_events_col.controls.append(
                ft.Row(
                    [
                        chk,
                        ft.Text(cfg["nome"], color=TEXT_COLOR, size=13, expand=True),
                        part,
                        ft.Text("Ordem:", color=TEXT_MUTED, size=11),
                        seq
                    ],
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN
                )
            )
            
        driver_events_col.controls.append(ft.Divider(height=15, color=PRIMARY_COLOR))
        driver_events_col.controls.append(ft.Text("Eventos Especiais (Despesas/Macros)", size=14, weight=ft.FontWeight.BOLD, color=ACCENT_COLOR))
        
        config_macros = [c for c in macro_configs if c["tipo"] == "macro"]
        if not config_macros:
            config_macros = [c for c in db.get_event_configs(empresa_id=current_empresa_id) if c["tipo"] == "macro"]
            
        for cfg in config_macros:
            is_checked = cfg["id"] in atribuidos_map
            chk = ft.Checkbox(value=is_checked, fill_color=ACCENT_COLOR)
            check_controls[cfg["id"]] = chk
            
            driver_events_col.controls.append(
                ft.Row(
                    [
                        chk,
                        ft.Text(cfg["nome"], color=TEXT_COLOR, size=14, expand=True)
                    ]
                )
            )
            
        def salvar_atribuicoes(e):
            try:
                for cfg_id, chk in check_controls.items():
                    if chk.value:
                        ordem = 0
                        part_val = True
                        if cfg_id in seq_controls:
                            try:
                                ordem = int(seq_controls[cfg_id].value)
                            except ValueError:
                                ordem = 0
                        if cfg_id in part_controls:
                            part_val = part_controls[cfg_id].value
                        db.assign_evento_to_usuario(selected_driver_id, cfg_id, ordem, part_val)
                    else:
                        db.remove_evento_from_usuario(selected_driver_id, cfg_id)
                show_toast("Atribuições de eventos salvas com sucesso!")
                show_driver_config(selected_driver_id, selected_driver_name)
            except Exception as ex:
                show_toast(f"Erro ao salvar atribuições: {ex}", True)
                
        driver_events_col.controls.append(ft.Divider(height=15, color=ft.colors.TRANSPARENT))
        driver_events_col.controls.append(
            ft.ElevatedButton(
                "Salvar Atribuições",
                icon=ft.icons.SAVE,
                on_click=salvar_atribuicoes,
                bgcolor=ACCENT_COLOR,
                color=TEXT_COLOR,
                width=300
            )
        )
        
        driver_config_panel.visible = True
        page.update()

    def reload_users_ui():
        load_data()
        users_list_ui.controls.clear()
        
        for u in usuarios:
            veh_info = ""
            if u.get("role") == "motorista" and u.get("veiculo_id"):
                veh = [v for v in veiculos if v["id"] == u["veiculo_id"]]
                if veh:
                    veh_info = f" | Van: {veh[0]['placa']}"
                    
            def make_click_handler(u_id=u["id"], u_nome=u["nome"], u_role=u["role"]):
                return lambda e: show_driver_config(u_id, u_nome) if u_role == "motorista" else None

            card = ft.Container(
                content=ft.Row(
                    [
                        ft.Icon(ft.icons.PERSON if u.get("role") != "motorista" else ft.icons.LOCAL_SHIPPING, color=PRIMARY_COLOR),
                        ft.Column(
                            [
                                ft.Text(u["nome"], color=TEXT_COLOR, size=16, weight=ft.FontWeight.BOLD),
                                ft.Text(f"Email: {u['email']} | Perfil: {u['role'].capitalize()}{veh_info}", color=TEXT_MUTED, size=13),
                            ],
                            spacing=2,
                            expand=True
                        ),
                        ft.Text(f"Senha: {u.get('senha', '---')}", color=ACCENT_COLOR, size=14, weight=ft.FontWeight.W_500)
                    ],
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN
                ),
                bgcolor=SURFACE_LIGHT,
                padding=10,
                border_radius=8,
                on_click=make_click_handler() if u.get("role") == "motorista" else None
            )
            users_list_ui.controls.append(card)
        page.update()

    def add_new_user(e):
        nome = new_user_name.value
        email = new_user_email.value
        senha = new_user_password.value
        role = new_user_role.value

        if not nome or not email or not senha:
            show_toast("Todos os campos são obrigatórios!", True)
            return

        try:
            db.add_usuario(nome, email, role, senha, current_empresa_id)
            show_toast(f"Usuário '{nome}' cadastrado com sucesso!")
            new_user_name.value = ""
            new_user_email.value = ""
            new_user_password.value = ""
            reload_users_ui()
        except Exception as ex:
            show_toast(f"Erro ao criar usuário: {ex}", True)

    new_user_name = ft.TextField(label="Nome", border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT, expand=True)
    new_user_email = ft.TextField(label="Email", border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT, expand=True)
    new_user_password = ft.TextField(label="Senha", border_color=PRIMARY_COLOR, bgcolor=SURFACE_LIGHT, expand=True)
    new_user_role = ft.Dropdown(
        label="Perfil",
        options=[ft.dropdown.Option("motorista"), ft.dropdown.Option("gestor"), ft.dropdown.Option("admin")],
        value="motorista",
        border_color=PRIMARY_COLOR,
        bgcolor=SURFACE_LIGHT,
        width=150
    )

    driver_config_panel = ft.Container(
        content=ft.Column(
            [
                driver_detail_title,
                ft.Divider(color=PRIMARY_COLOR),
                driver_vehicle_dropdown,
                ft.Divider(height=10, color=ft.colors.TRANSPARENT),
                driver_events_col
            ],
            expand=True
        ),
        bgcolor=SURFACE_LIGHT,
        padding=15,
        border_radius=8,
        visible=False,
        width=380
    )

    usuarios_split_row = ft.Row(
        [
            ft.Column(
                [
                    ft.Row([new_user_name, new_user_email, new_user_password, new_user_role], vertical_alignment=ft.CrossAxisAlignment.CENTER),
                    ft.ElevatedButton("Cadastrar Usuário", icon=ft.icons.PERSON_ADD, on_click=add_new_user, bgcolor=PRIMARY_COLOR, color=TEXT_COLOR),
                    ft.Divider(height=20, color=ft.colors.TRANSPARENT),
                    ft.Text("Usuários da Empresa (Clique em um motorista para configurar)", size=15, color=TEXT_MUTED, weight=ft.FontWeight.W_500),
                    users_list_ui
                ],
                expand=True
            ),
            driver_config_panel
        ],
        expand=True,
        vertical_alignment=ft.CrossAxisAlignment.START
    )

    usuarios_panel = ft.Container(
        content=ft.Column(
            [
                ft.Text("Gerenciamento de Usuários", size=20, weight=ft.FontWeight.BOLD, color=TEXT_COLOR),
                ft.Divider(color=PRIMARY_COLOR),
                usuarios_split_row
            ],
            expand=True
        ),
        bgcolor=SURFACE_COLOR,
        padding=20,
        border_radius=12,
        expand=True
    )

    # Inicia os dropdowns e dados iniciais
    reload_configs_ui()
    reload_veiculos_ui()
    load_admin_types()
    reload_reports_ui()
    load_trechos_dropdowns()
    reload_users_ui()
    reload_sandbox_ui()

    # --- LAYOUT PRINCIPAL DO BACKOFFICE ---
    lancamentos_panel = ft.Container(
        content=admin_tabs,
        bgcolor=SURFACE_COLOR,
        padding=20,
        border_radius=12,
        expand=True
    )

    tabs = ft.Tabs(
        selected_index=0,
        tabs=[
            ft.Tab(text="Relatórios e Trechos", icon=ft.icons.BAR_CHART, content=reports_panel),
            ft.Tab(text="Incluir Lançamentos Manuais", icon=ft.icons.ADD_BOX, content=lancamentos_panel),
            ft.Tab(text="Gerenciar Veículos", icon=ft.icons.LOCAL_SHIPPING, content=veiculos_panel),
            ft.Tab(text="Gerenciar Configurações", icon=ft.icons.SETTINGS, content=config_panel),
            ft.Tab(text="Sandbox Manager", icon=ft.icons.BUILD, content=sandbox_panel),
            ft.Tab(text="Gerenciar Usuários", icon=ft.icons.PEOPLE, content=usuarios_panel),
        ],
        expand=True,
        label_color=PRIMARY_COLOR,
        indicator_color=PRIMARY_COLOR
    )

    # Dropdown de empresas no topo para simulação multi-tenant
    def on_company_change(e):
        nonlocal current_empresa_id, selected_driver_id
        selected_driver_id = None
        driver_config_panel.visible = False
        current_empresa_id = company_filter_dropdown.value
        load_data()
        reload_configs_ui()
        reload_veiculos_ui()
        load_admin_types()
        reload_reports_ui()
        load_trechos_dropdowns()
        reload_users_ui()
        show_toast("Visualizando dados da empresa selecionada!")

    company_filter_dropdown = ft.Dropdown(
        label="Empresa / Tenant",
        options=[ft.dropdown.Option(c["id"], c["nome"]) for c in DEMO_COMPANIES],
        value=current_empresa_id,
        on_change=on_company_change,
        width=300,
        border_color=PRIMARY_COLOR,
        bgcolor=SURFACE_LIGHT,
        color=TEXT_COLOR
    )

    def reload_all(e=None):
        nonlocal selected_driver_id
        selected_driver_id = None
        driver_config_panel.visible = False
        load_companies()
        company_filter_dropdown.options = [ft.dropdown.Option(c["id"], c["nome"]) for c in DEMO_COMPANIES]
        company_filter_dropdown.value = current_empresa_id
        load_data()
        reload_configs_ui()
        reload_veiculos_ui()
        load_admin_types()
        reload_reports_ui()
        load_trechos_dropdowns()
        reload_users_ui()
        show_toast("Dados e empresas atualizados!")

    # Top Navbar com ações administrativas de despesas
    page.add(
        ft.Row(
            [
                ft.Text("SmartFrota - Backoffice", size=26, weight=ft.FontWeight.BOLD, color=TEXT_COLOR),
                ft.Row(
                    [
                        company_filter_dropdown,
                        ft.IconButton(ft.icons.REFRESH, on_click=reload_all)
                    ],
                    spacing=10
                )
            ],
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN
        ),
        ft.Divider(height=20, color=ft.colors.TRANSPARENT),
        ft.Row(
            [
                ft.Container(content=tabs, expand=True)
            ],
            expand=True,
            vertical_alignment=ft.CrossAxisAlignment.START
        )
    )

if __name__ == "__main__":
    ft.app(target=main)
