import database as db
import sqlite3

event_id = 'fcfdfa4c-6c15-44a0-9fff-af722e6b5209'
print('Attempting to delete event from Supabase and local DB:', event_id)

# Try delete from Supabase if online
try:
    if db.verificar_conexao():
        try:
            db._make_request('DELETE', 'sf_eventos_diarios', params=[('id', f'eq.{event_id}')])
            print('Deleted from Supabase (DELETE request sent)')
        except Exception as e:
            print('Error deleting from Supabase:', e)
    else:
        print('No connection to Supabase; skipping remote deletion')
except Exception as e:
    print('verificar_conexao failed:', e)

# Delete from local DB
conn = sqlite3.connect(db.SQLITE_PATH)
c = conn.cursor()
c.execute('SELECT COUNT(*) FROM sf_local_diarios WHERE id = ?', (event_id,))
print('Local exists before delete:', c.fetchone()[0])
c.execute('DELETE FROM sf_local_diarios WHERE id = ?', (event_id,))
conn.commit()
c.execute('SELECT COUNT(*) FROM sf_local_diarios WHERE id = ?', (event_id,))
print('Local exists after delete:', c.fetchone()[0])
conn.close()
