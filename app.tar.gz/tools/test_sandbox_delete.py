import sqlite3, uuid
DB='local_cache.db'
conn=sqlite3.connect(DB)
c=conn.cursor()
# ensure sandbox table
c.execute("INSERT OR REPLACE INTO sf_local_sandbox (empresa_id) VALUES (?)", ('sandbox-test',))
# insert two diario rows, one sandbox, one normal, both sincronizado=1
c.execute("INSERT OR REPLACE INTO sf_local_diarios (id, nome_evento, data_hora, km_atual, empresa_id, usuario_id, sincronizado) VALUES (?, ?, ?, ?, ?, ?, 1)", (str(uuid.uuid4()), 'EV1', '2026-08-13T12:00:00+00:00', 10.0, 'sandbox-test', 'u1'))
c.execute("INSERT OR REPLACE INTO sf_local_diarios (id, nome_evento, data_hora, km_atual, empresa_id, usuario_id, sincronizado) VALUES (?, ?, ?, ?, ?, ?, 1)", (str(uuid.uuid4()), 'EV2', '2026-08-13T12:01:00+00:00', 20.0, 'real-1', 'u2'))
conn.commit()
# counts before
c.execute("SELECT COUNT(*) FROM sf_local_diarios"); print('before total', c.fetchone()[0])
c.execute("SELECT COUNT(*) FROM sf_local_diarios WHERE empresa_id='sandbox-test'"); print('before sandbox', c.fetchone()[0])
# run the delete logic same as atualizar_cache_local
c.execute("""
DELETE FROM sf_local_diarios
WHERE sincronizado = 1
AND (empresa_id IS NULL OR empresa_id NOT IN (SELECT empresa_id FROM sf_local_sandbox))
""")
conn.commit()
# counts after
c.execute("SELECT COUNT(*) FROM sf_local_diarios"); print('after total', c.fetchone()[0])
c.execute("SELECT COUNT(*) FROM sf_local_diarios WHERE empresa_id='sandbox-test'"); print('after sandbox', c.fetchone()[0])
c.execute("SELECT COUNT(*) FROM sf_local_diarios WHERE empresa_id='real-1'"); print('after real-1', c.fetchone()[0])
# cleanup inserted rows
c.execute("DELETE FROM sf_local_diarios WHERE empresa_id IN ('sandbox-test','real-1')")
c.execute("DELETE FROM sf_local_sandbox WHERE empresa_id='sandbox-test'")
conn.commit()
conn.close()
print('test complete')
