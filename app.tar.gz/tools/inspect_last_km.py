import sqlite3
from datetime import datetime

DB = 'local_cache.db'
name_search = 'demo'

def parse_iso(s):
    if not s:
        return None
    s = s.replace('Z', '+00:00')
    try:
        return datetime.fromisoformat(s)
    except Exception:
        try:
            return datetime.strptime(s.split('.')[0], '%Y-%m-%dT%H:%M:%S')
        except Exception:
            return None

conn = sqlite3.connect(DB)
conn.row_factory = sqlite3.Row
c = conn.cursor()

print('Searching users like:', name_search)
c.execute("SELECT id, nome FROM sf_local_usuarios WHERE nome LIKE ?", (f'%{name_search}%',))
users = c.fetchall()
if not users:
    print('No users found matching name')
else:
    for u in users:
        uid = u['id']
        print('\nUser:', u['nome'], uid)
        # Last diario
        c.execute("SELECT km_atual, data_hora, sincronizado FROM sf_local_diarios WHERE usuario_id = ? ORDER BY data_hora DESC LIMIT 5", (uid,))
        diarios = c.fetchall()
        print('\nLast diarios (up to 5):')
        for d in diarios:
            print('  ', d['data_hora'], 'km_atual=', d['km_atual'], 'sincronizado=', d['sincronizado'])
        # Last macro
        c.execute("SELECT km_atual, data_hora, sincronizado FROM sf_local_macros WHERE usuario_id = ? ORDER BY data_hora DESC LIMIT 5", (uid,))
        macros = c.fetchall()
        print('\nLast macros (up to 5):')
        for m in macros:
            print('  ', m['data_hora'], 'km_atual=', m['km_atual'], 'sincronizado=', m['sincronizado'])

        # Compute last_km per local logic
        last_km = 0.0
        t_diario = None
        km_diario = None
        if diarios:
            for d in diarios:
                if d['km_atual'] is not None:
                    km_diario = float(d['km_atual'])
                    t_diario = parse_iso(d['data_hora'])
                    break
        t_macro = None
        km_macro = None
        if macros:
            for m in macros:
                if m['km_atual'] is not None:
                    km_macro = float(m['km_atual'])
                    t_macro = parse_iso(m['data_hora'])
                    break
        print('\nParsed last times:')
        print('  diario:', t_diario, 'km=', km_diario)
        print('  macro :', t_macro, 'km=', km_macro)
        if t_diario or t_macro:
            if not t_macro or (t_diario and t_diario > t_macro):
                last_km = km_diario or 0.0
            else:
                last_km = km_macro or 0.0
        print('\nComputed last_km=', last_km)

conn.close()
