import sqlite3
from datetime import datetime, timezone, timedelta
DB='local_cache.db'
conn=sqlite3.connect(DB)
conn.row_factory = sqlite3.Row
c=conn.cursor()
# UTC start of today
now = datetime.now(timezone.utc)
start = datetime(now.year, now.month, now.day, tzinfo=timezone.utc).isoformat()
end = (datetime(now.year, now.month, now.day, tzinfo=timezone.utc) + timedelta(days=1)).isoformat()
print('UTC Today start:', start)

# total counts
c.execute('SELECT COUNT(*) FROM sf_local_diarios')
print('total_diarios:', c.fetchone()[0])
# synced vs unsynced
c.execute('SELECT COUNT(*) FROM sf_local_diarios WHERE sincronizado = 1')
print('synced_count:', c.fetchone()[0])
c.execute('SELECT COUNT(*) FROM sf_local_diarios WHERE sincronizado = 0')
print('unsynced_count:', c.fetchone()[0])
# today counts
c.execute('SELECT COUNT(*) FROM sf_local_diarios WHERE data_hora >= ? AND data_hora < ?', (start, end))
print('today_count (UTC):', c.fetchone()[0])
# today synced/unsynced
c.execute('SELECT COUNT(*) FROM sf_local_diarios WHERE sincronizado=1 AND data_hora >= ? AND data_hora < ?', (start, end))
print('today_synced:', c.fetchone()[0])
c.execute('SELECT COUNT(*) FROM sf_local_diarios WHERE sincronizado=0 AND data_hora >= ? AND data_hora < ?', (start, end))
print('today_unsynced:', c.fetchone()[0])

# show last 30 rows ordered desc
print('\nLast 30 eventos (most recent first):')
c.execute('SELECT id, nome_evento, data_hora, km_atual, empresa_id, usuario_id, sincronizado FROM sf_local_diarios ORDER BY data_hora DESC LIMIT 30')
rows = c.fetchall()
for r in rows:
    print(dict(r))

conn.close()
